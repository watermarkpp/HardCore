extends Node

const FIXTURE_MONSTER_ID := 19
## The central outdoor authored spawn avoids the Home polygon and map edge.
const FIXTURE_GROUND_POSITION := Vector2(40.5, 13.5)
const WorldSpatialRulesScript := preload("res://scripts/world_spatial_rules.gd")


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	PlayerState.test_mode = true
	PlayerState.reset_progress(false)
	PlayerState.level = 50
	PlayerState.profession = "法师"
	PlayerState.learned_skills = {"雷电术": 3}
	PlayerState.recalculate_stats()
	var game: Node = load("res://scenes/main.tscn").instantiate()
	add_child(game)
	await get_tree().process_frame
	await get_tree().process_frame
	await _wait_for_formal_world(game)
	var caster: PlayerCharacter = game.player
	caster.current_mp = 100
	var caster_ground: Vector2 = FIXTURE_GROUND_POSITION - Vector2(2.0, 0.0)
	var caster_position: Vector2 = game._canonical_ground_gu_to_screen_px(caster_ground)
	assert(caster_position.is_finite(), "canonical skill fixture needs a finite map projection")
	game._set_player_world_position(caster_position)
	assert(
		not WorldSpatialRulesScript.point_inside_safe_zones_ground_gu(
			caster_ground,
			game._active_safe_zones,
		),
		"canonical skill caster fixture must be outside the authored safe area"
	)
	for value: Variant in get_tree().get_nodes_in_group("enemies"):
		if value is EnemyActor:
			(value as EnemyActor).global_position = caster.global_position + Vector2(3000, 3000)
	var target_position: Vector2 = game._canonical_ground_gu_to_screen_px(FIXTURE_GROUND_POSITION)
	var target: EnemyActor = _make_enemy(game, caster, target_position)
	game.locked_target = target
	game._set_magic_locked_target(target, true)
	game._skill_cast_target = target
	var hp_before := target.current_hp
	var mana_before := caster.current_mp
	var lightning: Dictionary = game._execute_canonical_skill(
		"雷电术",
		caster.global_position,
		Vector2.RIGHT,
		999999
	)
	if target.current_hp >= hp_before:
		var lightning_plan: Dictionary = lightning.get("canonical_plan", {})
		var lightning_snapshot: Dictionary = lightning_plan.get("canonical_snapshot", {})
		var lightning_actions: Array = lightning_plan.get("gameplay_actions", [])
		var lightning_effect: Dictionary = lightning_actions[0] if not lightning_actions.is_empty() else {}
		var lightning_query_plan: Dictionary = game._aoe_spell_query_plan(
			"wizard.lightning",
			[],
			lightning_effect,
			{},
			lightning_snapshot,
			game._canonical_screen_px_to_ground_gu(caster.global_position),
			{}
		)
		print(
			("CANONICAL_LIGHTNING_FAILURE target_px=%s target_ground=%s caster_ground=%s "
			+ "runtime_map=%d target_map=%d projection=%s spatial=%d safe=%s in_range=%s "
			+ "plan_rejection=%s query_failure=%s query_ready=%s projection_rejection=%s missing_projection=%d")
			% [
				str(target.global_position),
				str(game._canonical_screen_px_to_ground_gu(target.global_position)),
				str(game._canonical_screen_px_to_ground_gu(caster.global_position)),
				int(game.get("current_map_id")),
				target.runtime_map_id,
				str(target.projection_ready()),
				target.spatial_actor_runtime_id,
				str(WorldSpatialRulesScript.point_inside_safe_zones_ground_gu(FIXTURE_GROUND_POSITION, game._active_safe_zones)),
				str(game._is_magic_target_in_range(target)),
				str(lightning_plan.get("rejection", {})),
				str(lightning_query_plan.get("failure_reason", "")),
				str(game._aoe_plan_is_ready(lightning_query_plan)),
				str(game.projection_rejection_reason),
				game.missing_projection_rejection_count,
			]
		)
	assert(lightning.get("runtime_contract", "") == "skills.runtime_router.cn_mir2_176.v1", "真实入口必须经过SkillRuntimeRouter.build_canonical_plan")
	assert(lightning.get("adapter_contract", "") == "skills.production_adaptation.hardcore.v1", "真实入口缺少六类生产适配合同")
	assert(caster.current_mp == mana_before - 15, "雷电术未按canonical rank3唯一提交15MP")
	assert(target.current_hp < hp_before and hp_before - target.current_hp < 999999, "GameRoot仍采信客户端伤害或未应用canonical伤害")
	assert(_has_formal_visual(game, "wizard.lightning"), "雷电术canonical真实入口未创建稳定source_skill_id正式视觉")

	PlayerState.learned_skills = {
		SkillDataLoader.display_name("wizard.holy_word"): 3,
	}
	caster.current_mp = 100
	var zuma_ground: Vector2 = FIXTURE_GROUND_POSITION + Vector2(4.0, 0.0)
	var zuma_position: Vector2 = game._canonical_ground_gu_to_screen_px(zuma_ground)
	assert(
		not WorldSpatialRulesScript.point_inside_safe_zones_ground_gu(
			zuma_ground,
			game._active_safe_zones,
		),
		"Holy Word fixture must be outside the authored safe area"
	)
	var zuma_guard: EnemyActor = _make_enemy(game, caster, zuma_position, 156)
	game._set_magic_locked_target(zuma_guard, true)
	game._skill_cast_target = zuma_guard
	var holy_word: Dictionary = game._execute_canonical_skill(
		"wizard.holy_word",
		caster.global_position,
		Vector2.RIGHT,
		0,
		{"force_success": true}
	)
	assert(bool(holy_word.get("accepted", false)), "祖玛卫士未进入圣言术正式资格判定")
	assert(bool(holy_word.get("effect_success", false)), "强制成功的祖玛卫士圣言术没有生效")
	assert(zuma_guard.current_hp == 0, "圣言术成功后没有将祖玛卫士生命归零")

	game._set_magic_locked_target(target, true)
	game._skill_cast_target = target
	var living_hp_before := target.current_hp
	var rejected_holy_word: Dictionary = game._execute_canonical_skill(
		"wizard.holy_word",
		caster.global_position,
		Vector2.RIGHT,
		0,
		{"force_success": true}
	)
	assert(not bool(rejected_holy_word.get("accepted", true)), "普通活物被错误加入圣言术资格")
	assert(target.current_hp == living_hp_before, "圣言术资格失败后仍对普通活物造成伤害")

	PlayerState.learned_skills = {"瞬息移动": 3, "火墙": 3}
	caster.current_mp = 100
	var teleport_origin := caster.global_position
	var teleport_destination: Vector2 = game._find_valid_skill_teleport_position(
		teleport_origin
	)
	assert(teleport_destination != teleport_origin, "测试地图没有可用的瞬息移动目标点")
	var teleport: Dictionary = game._execute_canonical_skill(
		"瞬息移动",
		teleport_origin,
		Vector2.RIGHT,
		0,
		{
			"force_success": true,
			"destination_valid": true,
			"destination_ground_gu": game._canonical_screen_px_to_ground_gu(teleport_destination),
			"destination_tile": game._canonical_screen_px_to_grid_cell(teleport_destination),
		}
	)
	assert(bool(teleport.get("effect_success", false)), "瞬息移动canonical真实入口未完成移动")
	assert(caster.global_position != teleport_origin, "瞬息移动成功后玩家位置未改变")
	assert(
		_has_formal_visual(game, "wizard.teleport", "")
		and _has_formal_visual(game, "wizard.teleport", "arrival"),
		"瞬息移动canonical真实入口未创建主库离场/到达两阶段动画"
	)

	var fire_wall_origin_ground: Vector2 = game._canonical_screen_px_to_ground_gu(
		caster.global_position
	)
	var fire_wall_ground: Vector2 = fire_wall_origin_ground + Vector2(4.0, 0.0)
	var fire_wall_position: Vector2 = game._canonical_ground_gu_to_screen_px(fire_wall_ground)
	assert(fire_wall_position.is_finite(), "Fire Wall fixture needs a finite map projection")
	assert(
		not WorldSpatialRulesScript.point_inside_safe_zones_ground_gu(
			fire_wall_ground,
			game._active_safe_zones,
		),
		"Fire Wall fixture must remain outside the authored safe area",
	)
	target.set_combat_position(fire_wall_position, &"test_fire_wall_target")
	game._set_magic_locked_target(target, true)
	game._skill_cast_target = target
	var fire_wall: Dictionary = game._execute_canonical_skill(
		"火墙",
		caster.global_position,
		Vector2.RIGHT,
		0,
		{"primary_stat_roll": 8}
	)
	assert(bool(fire_wall.get("accepted", false)), "火墙canonical真实入口被拒绝")
	var fire_wall_visual_count := 0
	for child: Node in game.get_children():
		if not child is FireWallFieldController:
			continue
		for cell: GroundSkillVisualCell in (child as FireWallFieldController).visual_cells:
			fire_wall_visual_count += 1
			assert(
				cell._sprite != null and cell._sprite.frame_count() == 6,
				"火墙未加载主库1630..1635六帧动画"
			)
	assert(
		fire_wall_visual_count == 9,
		"火墙canonical真实入口必须按当前主合同创建3×3九格动画"
	)

	PlayerState.learned_skills = {
		SkillDataLoader.display_name("wizard.magic_shield"): 3,
	}
	caster.current_mp = 100
	var shield_result: Dictionary = game._execute_canonical_skill(
		"wizard.magic_shield",
		caster.global_position,
		Vector2.DOWN,
		0,
		{"primary_stat_roll": 12}
	)
	assert(bool(shield_result.get("accepted", false)), "魔法盾正式入口被拒绝")
	assert(bool(caster.magic_shield_snapshot().get("active", false)))
	var persistent_shields := get_tree().get_nodes_in_group(
		"wizard_magic_shield_persistent_visual"
	)
	assert(persistent_shields.size() == 1, "魔法盾未创建唯一常驻正式视觉")
	var persistent_shield := persistent_shields[0] as CasterSkillVisualEffect
	assert(persistent_shield.target_node == caster)
	var persistent_sprite: CasterSkillAnimationPlayer = persistent_shield._sprites[0]
	# Combat sequences now warm asynchronously as a complete unit. Playback is
	# intentionally frozen until resident; elapsed playback time starts there.
	var shield_warm_deadline := Time.get_ticks_msec() + 3000
	while not persistent_sprite.visual_loaded and Time.get_ticks_msec() < shield_warm_deadline:
		await get_tree().process_frame
	assert(persistent_sprite.visual_loaded, "魔法盾整段动画资源未能就绪")
	persistent_sprite._process(persistent_sprite.animation_duration() + 0.01)
	persistent_shield._process(0.1)
	assert(
		persistent_sprite.playback_complete
		and persistent_sprite.current_frame_index == persistent_sprite.frame_count() - 1,
		"魔法盾没有在成形动画后保留完整末帧"
	)
	assert(not persistent_shield.is_queued_for_deletion())
	caster.shield_capacity = 0.0
	persistent_shield._process(0.01)
	assert(persistent_shield.is_queued_for_deletion(), "魔法盾容量耗尽后视觉仍未移除")
	await get_tree().process_frame

	PlayerState.profession = "道士"
	PlayerState.learned_skills = {"召唤神兽": 3}
	PlayerState.inventory = []
	PlayerState.recalculate_stats()
	caster.current_mp = 100
	var summon_result: Dictionary = game._execute_canonical_skill(
		"召唤神兽",
		caster.global_position,
		Vector2.DOWN,
		0
	)
	assert(bool(summon_result.get("accepted", false)), "召唤神兽canonical真实入口被拒绝")
	var summon_resource_cost: Dictionary = summon_result.get(
		"canonical_plan", {}
	).get("resource_cost", {})
	assert(PlayerState.inventory.is_empty(), "召唤神兽不得消耗施法材料")
	assert(
		int(summon_resource_cost.get("material_amount", -1)) == 0
		and str(summon_resource_cost.get("material_id", "invalid")).is_empty(),
		"召唤神兽canonical计划必须保持道士零材料合同"
	)
	assert(
		str(summon_resource_cost.get("material_policy_contract_id", ""))
		== "skills.taoist.material_free.v1"
	)
	var main_pet: SummonActor = game._canonical_main_pet()
	assert(main_pet != null and main_pet.skill_id == "taoist.summon_divine_beast", "道士唯一主宠未携带稳定source_skill_id")
	assert(main_pet._sprite != null, "召唤神兽canonical主宠未加载正式动画")
	var first_pet_id := main_pet.get_instance_id()
	var recall: Dictionary = game._execute_canonical_skill("召唤神兽", caster.global_position, Vector2.DOWN, 0)
	assert(bool(recall.get("accepted", false)) and game._canonical_main_pet().get_instance_id() == first_pet_id, "已有道士主宠未执行召回而是替换")

	game.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	print("CANONICAL_SKILL_PRODUCTION_ENTRY_PASS")
	get_tree().quit(0)


func _make_enemy(
	game: Node,
	caster: PlayerCharacter,
	position: Vector2,
	monster_id: int = FIXTURE_MONSTER_ID,
) -> EnemyActor:
	var canonical_data: Dictionary = GameData.get_monster_by_id(monster_id)
	assert(
		not canonical_data.is_empty(),
		"canonical skill fixture monster_id=%d must exist" % monster_id
	)
	var enemy: EnemyActor = game._spawn_enemy(
		canonical_data,
		position,
		false,
		-1.0,
		{
			"respawn_enabled": false,
			"spawn_slot_id": "test:canonical_skill:%d" % monster_id,
		},
	)
	assert(
		enemy != null
			and enemy.monster_id == monster_id
			and not enemy.is_boss
			and enemy.runtime_map_id == int(game.get("current_map_id"))
			and enemy.projection_ready()
			and enemy.spatial_actor_runtime_id > 0,
		"canonical skill fixture must use the formal exact-ID mapped spawn"
	)
	enemy.max_hp = 9999
	enemy.current_hp = enemy.max_hp
	enemy.control_time = 60.0
	assert(
		is_instance_valid(enemy)
		and not enemy.is_queued_for_deletion()
		and enemy.can_receive_damage(),
		"canonical skill fixture target must survive exact-ID admission"
	)
	return enemy


func _wait_for_formal_world(game: Node) -> void:
	var deadline_ms: int = Time.get_ticks_msec() + 5000
	while Time.get_ticks_msec() < deadline_ms:
		var current_map_id: int = int(game.get("current_map_id"))
		var input_enabled: bool = bool(game.call("gameplay_input_is_enabled"))
		if current_map_id >= 0 and input_enabled:
			break
		await get_tree().process_frame
	assert(
		int(game.get("current_map_id")) == GameData.service_runtime_map_id(0),
		"canonical skill fixture must wait for the formal mapped world"
	)
	assert(not game._active_safe_zones.is_empty(), "canonical skill fixture needs the formal safe-zone context")


func _has_formal_visual(
	game: Node,
	stable_skill_id: String,
	phase_id := ""
) -> bool:
	for child: Node in game.get_children():
		if (
			child is CasterSkillVisualEffect
			and child.skill_id == stable_skill_id
			and child.phase_id == phase_id
		):
			return true
	return false
