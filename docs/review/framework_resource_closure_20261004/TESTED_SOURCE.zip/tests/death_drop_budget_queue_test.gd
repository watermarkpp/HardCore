extends Node

const GameRootScript := preload("res://scripts/game_root.gd")
const SpatialIndexScript := preload("res://scripts/runtime_combat_spatial_index.gd")
const LootRuntimeScript := preload(
	"res://scripts/layers/runtime/loot_runtime_service.gd"
)

class FixtureGameRoot extends GameRootScript:
	## Keep the real GameRoot._ready lifecycle (including the loot manager), but
	## do not start the production world bootstrap for this queue-only fixture.
	func _begin_initial_world_bootstrap() -> void:
		return

	# Queue-only fixture has no formal map geometry. Production placement and
	# real WORLD walls are exercised by loot_world_placement_integration_test.
	func _resolve_loot_ground_position(desired_px: Vector2, _death_origin := Vector2.INF) -> Vector2:
		return desired_px

	func _advance_loot_ground_position(desired_px: Vector2, _death_origin: Vector2, _search: Dictionary, _slice_started_usec: int, _budget_usec: int, _force_synchronous: bool) -> Dictionary:
		return {"complete": true, "position": desired_px, "progressed": true}

const MAP_ID := 5317
const GENERATION := 11
const MONSTER_ID := 34

var _failures: Array[String] = []
var _checks := 0
var _games: Array[Node] = []


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	PlayerState.test_mode = true
	PlayerState.reset_progress()
	RuntimeDiagnostics.set_device_lab_performance_enabled(true)
	RuntimeDiagnostics.reset_performance_window()
	_test_budget_and_progress()
	_test_time_budget_without_diagnostics()
	_test_save_failure_is_no_reward()
	_test_generation_guards()
	# These are separate scenarios. The real shared allowance is replenished
	# by a process iteration, rather than reset per fixture or per service.
	var previous_epoch := Engine.get_process_frames()
	while Engine.get_process_frames() == previous_epoch:
		await get_tree().process_frame
	_test_materialization_failure_is_terminal()
	_test_terminal_ledger_is_bounded()
	_finish()


func _new_game(seed_value: int) -> Node:
	RuntimeDiagnostics.reset_performance_window()
	var game: Node
	if _games.is_empty() or not is_instance_valid(_games[0]):
		game = FixtureGameRoot.new()
		game.current_map_id = MAP_ID
		game._zone_generation = GENERATION
		add_child(game)
		game.set_process(false)
		game.set_physics_process(false)
		if is_instance_valid(game.player):
			game.player.set_process(false)
			game.player.set_physics_process(false)
		_games.append(game)
	else:
		game = _games[0]
		for child: Node in game.get_children():
			if child is LootPickup:
				child.free()
		game._pending_enemy_deaths.clear()
		game._enemy_death_terminal_jobs.clear()
		game._enemy_death_terminal_total_count = 0
		game._enemy_death_sequence = 0
		game._last_death_logout_failure.clear()
		game._enemy_death_pipeline_running = false
		game._enemy_death_target_refresh_pending = false
		game._pending_loot_collections.clear()
		game._loot_collection_flush_queued = false
		if game._loot_pickup_runtime_manager != null:
			game._loot_pickup_runtime_manager.clear_all()
	game.current_map_id = MAP_ID
	game._zone_generation = GENERATION
	game._rng.seed = seed_value
	game._enemy_death_flush_queued = true
	game._combat_spatial_index = SpatialIndexScript.new()
	if game._loot_pickup_runtime_manager != null:
		game._loot_pickup_runtime_manager.configure_map(
			MAP_ID,
			GENERATION,
			Callable(self, "_identity_position"),
			Callable(self, "_identity_position"),
		)
		game._loot_pickup_runtime_manager.set_process(false)
	return game


func _identity_position(position: Vector2) -> Vector2:
	return position


func _queue_death(game: Node, position := Vector2.ZERO) -> void:
	var enemy := EnemyActor.new()
	enemy.global_position = position
	enemy.set_meta("respawn_enabled", false)
	enemy.set_meta("spawn_position", position)
	var canonical := GameData.get_monster_by_id(MONSTER_ID)
	var snapshot: Dictionary = game._build_enemy_death_runtime_snapshot(canonical)
	enemy.set_meta("death_runtime_snapshot", snapshot)
	enemy.set_meta("death_origin", {
		"captured": true,
		"map_id": game.current_map_id,
		"generation": game._zone_generation,
		"death_position": position,
		"spawn_position": position,
		"spawn_context": {},
	})
	game._on_enemy_died(enemy, canonical)
	enemy.free()


func _set_fixed_plan(game: Node, request_count: int) -> Dictionary:
	var death: Dictionary = game._pending_enemy_deaths[0]
	var requests: Array[Dictionary] = []
	for index: int in range(request_count):
		requests.append({
			"item_name": "金创药(小量)",
			"position": Vector2(float(index), float(index)),
		})
	death["drop_plan"] = {
		"roll": {},
		"requests": requests,
		"next_request_index": 0,
		"item_count": request_count,
		"gold_drop_count": 0,
		"materialized": false,
	}
	death["materialized_node_index"] = 0
	death["materialized_node_count"] = 0
	death["materialization_retry_count"] = 0
	death["state"] = "PLANNED"
	return death


func _test_budget_and_progress() -> void:
	var game := _new_game(1001)
	_queue_death(game)
	_expect(game._settle_pending_enemy_death_batch() == true, "budget fixture did not settle")
	var death := _set_fixed_plan(game, 3)
	_expect(game.set_death_drop_work_limits_for_test(1000000, 4, 1), "budget override rejected")
	game._pump_enemy_death_work_queue()
	_expect(
		game._pending_enemy_deaths.size() == 1
		and int(death.get("materialized_node_index", 0)) == 1,
		"node budget did not leave remaining work queued",
	)
	_expect(
		RuntimeDiagnostics.performance_counter(&"drop_node_spawn_count") == 1,
		"first budget slice did not materialize one node",
	)
	game._flush_enemy_deaths(false)
	_expect(game._pending_enemy_deaths.is_empty(), "budget queue failed to drain")
	_expect(
		game._enemy_death_terminal_jobs.size() == 1
		and str(game._enemy_death_terminal_jobs[0].get("state", "")) == "COMMITTED",
		"budgeted death did not commit in order",
	)
	_expect(
		RuntimeDiagnostics.performance_counter(&"drop_node_spawn_count") == 3,
		"budgeted materialization duplicated or lost a node",
	)
	game.clear_death_drop_work_limits_for_test()


func _test_time_budget_without_diagnostics() -> void:
	# Production normally has diagnostics disabled. Scheduling must still
	# honor its wall-clock budget; diagnostic timing tokens are then zero.
	RuntimeDiagnostics.set_device_lab_performance_enabled(false)
	ProjectSettings.set_setting(RuntimeDiagnostics.SETTING_ENABLED, false)
	RuntimeDiagnostics.refresh_performance_gate()
	_expect(not RuntimeDiagnostics.performance_timing_enabled(), "fixture must disable diagnostic timing")
	var game := _new_game(1010)
	_queue_death(game)
	_expect(game._settle_pending_enemy_death_batch(), "uninstrumented fixture did not settle")
	var death := _set_fixed_plan(game, 8)
	# Pass an already exhausted real slice. One node may make forward progress,
	# but the remainder must wait for the next slice regardless of node limit.
	var result: Dictionary = game._materialize_enemy_death_nodes(
		death, Time.get_ticks_usec() - 100000, 1200, 8, false)
	_expect(int(result.nodes) == 1, "disabled diagnostics bypassed drop time budget: %s" % result)
	_expect(int(death.materialized_node_index) == 1, "expired slice consumed the remaining drop plan")
	# Exercise the outer production pump as well: a one-microsecond budget
	# must yield and later synchronous draining must produce all eight once.
	game.set_death_drop_work_limits_for_test(1, 32, 8)
	var before := _loot_child_count(game)
	game._pump_enemy_death_work_queue()
	_expect(_loot_child_count(game) - before <= 1, "outer pump ignored the uninstrumented time budget")
	game._flush_enemy_deaths(false)
	_expect(_loot_child_count(game) == 8, "budgeted continuation lost or duplicated rewards")
	_expect(game._pending_enemy_deaths.is_empty(), "uninstrumented queue did not drain")
	game.clear_death_drop_work_limits_for_test()
	RuntimeDiagnostics.set_device_lab_performance_enabled(true)


func _test_save_failure_is_no_reward() -> void:
	var game := _new_game(1002)
	_queue_death(game)
	PlayerState.test_transaction_debug_reset()
	PlayerState._test_force_atomic_write_failure = true
	game._flush_enemy_deaths(false)
	PlayerState._test_force_atomic_write_failure = false
	_expect(game._pending_enemy_deaths.is_empty(), "save failure stranded queue")
	_expect(
		game._enemy_death_terminal_jobs.size() == 1
		and str(game._enemy_death_terminal_jobs[0].get("state", "")) == "FAILED",
		"save failure did not reach observable terminal state",
	)
	_expect(
		RuntimeDiagnostics.performance_counter(&"drop_roll_count") == 0,
		"save failure consumed drop RNG",
	)
	_expect(_loot_child_count(game) == 0, "save failure materialized loot")
	_expect(
		int(PlayerState.test_transaction_debug_snapshot().get("commit_attempts", 0))
		== 3,
		"save failure did not use bounded retries",
	)


func _test_generation_guards() -> void:
	var pre_roll_game := _new_game(1003)
	_queue_death(pre_roll_game)
	var pre_roll_state: int = pre_roll_game._rng.state
	pre_roll_game.current_map_id = MAP_ID + 1
	pre_roll_game._flush_enemy_deaths(false)
	_expect(
		str(pre_roll_game._enemy_death_terminal_jobs[0].get("state", "")) == "CANCELLED",
		"pre-roll map mismatch was not cancelled",
	)
	_expect(
		pre_roll_game._rng.state == pre_roll_state
		and RuntimeDiagnostics.performance_counter(&"drop_roll_count") == 0,
		"pre-roll mismatch consumed drop RNG",
	)

	var post_roll_game := _new_game(1004)
	_queue_death(post_roll_game)
	_expect(post_roll_game._settle_pending_enemy_death_batch(), "post-roll fixture did not settle")
	var post_roll_death: Dictionary = post_roll_game._pending_enemy_deaths[0]
	_expect(
		str(post_roll_death.get("state", "")) == "PLANNED",
		"post-roll fixture did not reserve a plan",
	)
	post_roll_game._zone_generation += 1
	post_roll_game._flush_enemy_deaths(false)
	_expect(
		str(post_roll_game._enemy_death_terminal_jobs[0].get("state", "")) == "CANCELLED",
		"post-roll generation mismatch materialized old-map loot",
	)
	_expect(
		RuntimeDiagnostics.performance_counter(&"drop_node_spawn_count") == 0,
		"post-roll mismatch spawned a node",
	)


func _test_materialization_failure_is_terminal() -> void:
	var game := _new_game(1005)
	_queue_death(game)
	_expect(game._settle_pending_enemy_death_batch(), "materialization fixture did not settle")
	_set_fixed_plan(game, 2)
	_expect(game.set_death_drop_work_limits_for_test(1000000, 4, 1), "materialization budget override rejected")
	_expect(game.set_loot_materialization_failure_count_for_test(0), "materialization success hook rejected")
	game._pump_enemy_death_work_queue()
	_expect(
		game._pending_enemy_deaths.size() == 1
		and int(game._pending_enemy_deaths[0].get("materialized_node_index", 0)) == 1
		and _loot_child_count(game) == 1,
		"first materialization node did not commit before the injected failure",
	)
	_expect(game.set_loot_materialization_failure_count_for_test(99), "failure hook rejected")
	game._flush_enemy_deaths(false)
	game.set_loot_materialization_failure_count_for_test(0)
	_expect(
		game._enemy_death_terminal_jobs.size() == 1
		and str(game._enemy_death_terminal_jobs[0].get("state", "")) == "FAILED",
		"materialization failure was not terminal after retries",
	)
	_expect(_loot_child_count(game) == 1, "failed materialization duplicated the successful node")
	_expect(
		RuntimeDiagnostics.performance_counter(&"death_queue_materialization_failures") == 3,
		"materialization failure retry count was not observable",
	)
	var terminal: Dictionary = game._enemy_death_terminal_jobs[0]
	var remaining: Variant = terminal.get("remaining_requests", [])
	_expect(
		remaining is Array
		and remaining.size() == 1
		and int(terminal.get("materialized_node_index", 0)) == 1
		and int(terminal.get("remaining_request_count", 0)) == 1
		and str(terminal.get("reward_status", "")) == "materialization_failed",
		"partial materialization lost explicit remaining request evidence",
	)
	game.clear_death_drop_work_limits_for_test()


func _test_terminal_ledger_is_bounded() -> void:
	var game := _new_game(1006)
	for index: int in range(80):
		game._pending_enemy_deaths.append({
			"state": "COMMITTED",
			"death_key": "ledger:%d" % index,
		})
	game._compact_enemy_death_queue()
	_expect(
		game._enemy_death_terminal_jobs.size() == GameRootScript.DEATH_TERMINAL_LEDGER_MAX,
		"terminal ledger exceeded its bounded retention window",
	)
	_expect(
		int(game._enemy_death_terminal_total_count) == 80
		and str(game._enemy_death_terminal_jobs[-1].get("death_key", "")) == "ledger:79",
		"terminal ledger did not retain latest record and total count",
	)


func _expect(condition: bool, message: String) -> void:
	_checks += 1
	if not condition:
		_failures.append(message)


func _loot_child_count(game: Node) -> int:
	var count := 0
	for child: Node in game.get_children():
		if child is LootPickup:
			count += 1
	return count


func _finish() -> void:
	PlayerState._test_force_atomic_write_failure = false
	for game: Node in _games:
		if is_instance_valid(game):
			game.free()
	RuntimeDiagnostics.set_device_lab_performance_enabled(false)
	PlayerState.test_mode = false
	if not _failures.is_empty():
		push_error("DEATH_DROP_BUDGET_QUEUE_FAIL: %s" % "; ".join(_failures))
		print("DEATH_DROP_BUDGET_QUEUE_FAIL checks=%d failures=%d" % [_checks, _failures.size()])
		get_tree().quit(1)
		return
	print(
		"DEATH_DROP_BUDGET_QUEUE_PASS checks=%d save_retry=3 generation_guards=2"
		% _checks
	)
	get_tree().quit(0)
