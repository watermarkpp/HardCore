extends Node


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	PlayerState.test_mode = true
	PlayerState.reset_progress()
	PlayerState.level = 35
	PlayerState.recalculate_stats()
	var game: Node = load("res://scenes/main.tscn").instantiate()
	add_child(game)
	await _wait_for_playable_world(game)
	# 正式启动点已是服务端HomeMap=0；职业技能综合测试显式进入带Boss的旧演示场。
	game.change_zone("比奇郊外")
	await get_tree().process_frame
	await get_tree().process_frame
	await _wait_for_playable_world(game)
	var enemy: EnemyActor
	var elite_fixture: EnemyActor
	for node: Node in get_tree().get_nodes_in_group("enemies"):
		if node is EnemyActor and not node.is_queued_for_deletion():
			if enemy == null:
				enemy = node
			if node.monster_id == 56:
				elite_fixture = node
	assert(elite_fixture != null, "旧演示场必须保留 canonical 精英 ID56")
	assert(not elite_fixture.is_boss, "精英不得变成Boss")
	assert(str(elite_fixture.get_meta("respawn_policy_id", "")) == "elite")
	assert(is_equal_approx(float(elite_fixture.get_meta("respawn_seconds", 0.0)), 1800.0))
	assert(enemy != null, "职业战斗测试缺少确定性目标")
	enemy.max_hp = 9999
	enemy.current_hp = 9999
	enemy.control_time = 60.0

	PlayerState.select_profession("法师")
	PlayerState.learned_skills = {"火球术": 3, "魔法盾": 3, "火墙": 3}
	game.player.current_mp = 200
	enemy.global_position = game.player.global_position + Vector2(75, 0)
	enemy.apply_control(10.0)
	var hp_before_fireball := enemy.current_hp
	game._on_player_skill("火球术", game.player.global_position, Vector2.RIGHT, 12)
	for frame in range(12):
		await get_tree().physics_frame
	assert(enemy.current_hp < hp_before_fireball, "法师投射物未命中")
	game._on_player_skill("魔法盾", game.player.global_position, Vector2.RIGHT, 10)
	assert(game.player.shield_time > 0.0 and game.player.damage_reduction > 0.0, "魔法盾未生效")
	enemy.global_position = game.player.global_position + Vector2(175, 0)
	enemy.apply_control(10.0)
	# Fire Wall is target-centred in the mobile spell-lock contract. This direct
	# production-entry test bypasses the HUD input path, so install the same
	# explicit lock/selected target that the real input path supplies.
	game._set_magic_locked_target(enemy, true)
	game._skill_cast_target = enemy
	assert(
		game._canonical_screen_px_to_grid_cell(enemy.global_position)
		== Vector2i(round(game._canonical_screen_px_to_ground_gu(enemy.global_position))),
		"旧区域整数技能格与怪物浮点脚点格使用了不同坐标系"
	)
	var hp_before_firewall := enemy.current_hp
	game._on_player_skill("火墙", game.player.global_position, Vector2.RIGHT, 10)
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(enemy.current_hp < hp_before_firewall, "火墙持续区域未造成伤害")

	PlayerState.select_profession("道士")
	PlayerState.learned_skills = {
		"施毒术": 3,
		"治愈术": 3,
		"困魔咒": 3,
		"隐身术": 3,
		"召唤骷髅": 3,
	}
	PlayerState.inventory = [
		{"name": "灰色药粉", "count": 10},
		{"name": "护身符", "count": 20},
	]
	game.player.current_mp = 200
	enemy.global_position = game.player.global_position + Vector2(75, 0)
	enemy.apply_control(10.0)
	game._on_player_skill("施毒术", game.player.global_position, Vector2.RIGHT, 12)
	for frame in range(12):
		await get_tree().physics_frame
	assert(enemy.poison_time > 0.0 and enemy.poison_damage > 0, "施毒术状态未生效")
	assert(enemy.canonical_red_poison_active(), "红毒状态未显示")
	game.player.take_damage(20)
	var hp_before_heal: int = game.player.current_hp
	game._on_player_skill("治愈术", game.player.global_position, Vector2.RIGHT, 12)
	assert(game.player.current_hp > hp_before_heal, "治愈术未恢复生命")
	var entrapment_center_cell: Vector2i = (
		game._canonical_screen_px_to_grid_cell(game.player.global_position)
		+ Vector2i(2, 0)
	)
	enemy.global_position = game._canonical_grid_cell_to_screen_px(
		entrapment_center_cell
	)
	enemy.control_time = 0.0
	game._set_magic_locked_target(enemy, true)
	game._on_player_skill("困魔咒", game.player.global_position, Vector2.RIGHT, 1)
	var entrapment_state := enemy.entrapment_state_snapshot()
	assert(bool(entrapment_state.get("active", false)), "困魔咒未建立边界状态")
	assert(
		str(entrapment_state.get("contract_id", ""))
		== "skills.taoist.entrapment.boundary_controller.v1"
	)
	assert(int(entrapment_state.get("boundary_cell_count", 0)) == 8)
	assert(entrapment_state.get("center_cell", Vector2i.ZERO) == entrapment_center_cell)
	assert(enemy.control_time == 0.0, "困魔咒不得退化为通用定身")
	game._on_player_skill("隐身术", game.player.global_position, Vector2.RIGHT, 1)
	assert(game.player.is_stealthed(), "隐身术未生效")
	game._on_player_skill("召唤骷髅", game.player.global_position, Vector2.RIGHT, 12)
	await get_tree().process_frame
	var summons := get_tree().get_nodes_in_group("summons")
	assert(summons.size() == 1 and summons[0] is SummonActor, "召唤骷髅未生成")
	var summon: SummonActor = summons[0]
	summon.global_position = enemy.global_position + Vector2(10, 0)
	enemy._threat_table.clear()
	enemy.target = null
	enemy._retarget()
	assert(enemy.target == summon, "怪物未将附近召唤物纳入仇恨目标")

	print("CLASS_COMBAT_PASS：法师投射物/火墙/魔法盾与道士治疗/毒/控制/隐身/召唤正常")
	get_tree().quit(0)


func _wait_for_playable_world(game: Node) -> void:
	for _frame in range(600):
		if (
			not game._world_bootstrap_in_progress
			and not game._map_transition_in_progress
			and game.gameplay_input_is_enabled()
		):
			return
		await get_tree().process_frame
	assert(false, "职业战斗测试等待地图进入可操作状态超时")
