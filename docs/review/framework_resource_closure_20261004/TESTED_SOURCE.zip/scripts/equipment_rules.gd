class_name EquipmentRules
extends RefCounted

const ItemCategories := preload("res://scripts/identity/item_category_identity.gd")

const NEED_LEVEL := 0
const NEED_ATTACK := 1
const NEED_MAGIC := 2
const NEED_TAO := 3
const SUPPORTED_NEEDS: Array[int] = [NEED_LEVEL, NEED_ATTACK, NEED_MAGIC, NEED_TAO]
const ATTRIBUTE_MASTER_CONTRACT_ID := "equipment.attribute.master.v2"
const ATTRIBUTE_MASTER_DISTRIBUTION := "project.hardcore.equipment_attribute_master.v2"
const LEGACY_ROLL_POLICY := "legacy_clamp_negative_span"
const SKILL_LEVEL_AFFIX_CONTRACT_ID := "equipment.skill_level_affix.v1"
const SKILL_LEVEL_AFFIX_STAT := "skill_level"
const SKILL_LEVEL_SCOPE_ALL := "all"
const SKILL_LEVEL_SCOPE_PREFIX_PROFESSION := "profession:"
const SKILL_LEVEL_SCOPE_PREFIX_SKILL := "skill:"
const SKILL_LEVEL_PROFESSIONS: Array[String] = ["warrior", "wizard", "taoist"]
const SKILL_LEVEL_INT64_MAX := 9223372036854775807
const SKILL_LEVEL_STABLE_ID_MAX_LENGTH := 128
const REQUIREMENT_TYPE_CODES := {
	"level": NEED_LEVEL,
	"max_dc": NEED_ATTACK,
	"max_mc": NEED_MAGIC,
	"max_sc": NEED_TAO,
}
const JOB_LOCK_DISPLAY_NAMES := {
	"warrior": "战士",
	"wizard": "法师",
	"taoist": "道士",
	"general": "通用",
}
const BLESSING_UNLUCKY_RATE := 20
const LUCK_POINT_1 := 1
const LUCK_POINT_2 := 3
const LUCK_POINT_3 := 7
const LUCK_POINT_2_RATE := 6
const LUCK_POINT_3_RATE := 40
const MAX_WEAPON_CURSE := 10
const ACTOR_VISUAL_SORT_CONTRACT_ID := "equipment_actor_visual_sort_unit_v3"
const MALE_WORLD_HELMET_EXTENSION_CONTRACT_ID := "equipment.world_helmet.male.extension.v1"
const PLAYER_VISUAL_HELMET_V2_CONTRACT_ID := "equipment.world_helmet.player_visual_v2"
const WORLD_HELMET_RUNTIME_POLICY_CONTRACT_ID := "equipment.world_helmet.runtime_visibility.v1"
const WORLD_HELMET_RUNTIME_POLICY_PATH := "res://assets/data/equipment_world_helmet_runtime_policy.json"
const ACTOR_VISUAL_BODY_LAYER := &"body_and_dress"
const ACTOR_VISUAL_HAIR_LAYER := &"hair"
const ACTOR_VISUAL_WEAPON_LAYER := &"weapon"
const ACTOR_VISUAL_HELMET_LAYER := &"helmet"
static var _world_helmet_runtime_policy: Dictionary = {}
const SPECIAL_EFFECTS_BY_NAME := {
	"隐身戒指": {"id": "stealth", "label": "隐身", "source_code": 111, "runtime": true, "confidence": "B"},
	"传送戒指": {"id": "teleport", "label": "安全传送", "source_code": 112, "runtime": true, "confidence": "B"},
	"麻痹戒指": {"id": "paralysis", "label": "近战麻痹", "source_code": 113, "runtime": true, "confidence": "B"},
	"复活戒指": {"id": "revival", "label": "60秒复活", "source_code": 114, "runtime": true, "confidence": "B"},
	"火焰戒指": {"id": "flame_skill", "label": "火球技能", "source_code": 115, "runtime": true, "confidence": "B"},
	"防御戒指": {"id": "recovery_skill", "label": "治愈技能", "source_code": 116, "runtime": true, "confidence": "B"},
	"护身戒指": {"id": "magic_shield", "label": "魔法值抵伤", "source_code": 118, "runtime": true, "confidence": "B"},
	"超负载戒指": {"id": "double_weight", "label": "负重上限翻倍", "source_code": 119, "runtime": true, "confidence": "B"},
}
const SET_PIECES_BY_NAME := {
	"魔血项链": {"set": "magic_blood", "piece": "necklace", "power": 25},
	"魔血手镯": {"set": "magic_blood", "piece": "bracelet", "power": 25},
	"魔血戒指": {"set": "magic_blood", "piece": "ring", "power": 25},
	"虹魔项链": {"set": "rainbow_demon", "piece": "necklace", "power": 4},
	"虹魔手镯": {"set": "rainbow_demon", "piece": "bracelet", "power": 3},
	"虹魔戒指": {"set": "rainbow_demon", "piece": "ring", "power": 2},
}


static var _weapon_frame_order: Dictionary = {}

static func weapon_draws_behind_actor(direction_row: int, action_name := "idle", frame := 0, gender := "男") -> bool:
	if _weapon_frame_order.is_empty():
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(
			"res://assets/data/equipment_weapon_frame_order.json"
		))
		if not parsed is Dictionary or str(parsed.get("contract_id", "")) != "equipment.weapon.primary_frame_order.v1":
			return false
		_weapon_frame_order = parsed
	var starts: Dictionary = _weapon_frame_order.get("action_starts", {})
	if not starts.has(action_name) or direction_row < 0 or direction_row > 7 or frame < 0 or frame > 7:
		return false
	var source_frame := int(starts[action_name]) + direction_row * 8 + frame
	var table: Array = _weapon_frame_order.get("genders", [])[1 if gender == "女" else 0]
	return source_frame < table.size() and int(table[source_frame]) == 0


static func world_helmet_runtime_policy() -> Dictionary:
	if _world_helmet_runtime_policy.is_empty():
		var parsed: Variant = JSON.parse_string(
			FileAccess.get_file_as_string(
				WORLD_HELMET_RUNTIME_POLICY_PATH
			)
		)
		_world_helmet_runtime_policy = (
			parsed if parsed is Dictionary else {}
		)
	return _world_helmet_runtime_policy


static func world_helmet_is_visible() -> bool:
	return bool(
		world_helmet_runtime_policy().get(
			"worldHelmet", {}
		).get("visible", false)
	)


static func world_helmet_head_mask_enabled() -> bool:
	return bool(
		world_helmet_runtime_policy().get(
			"worldHelmet", {}
		).get("headOcclusionMaskEnabled", false)
	)


static func world_hair_appearance() -> Dictionary:
	var value: Variant = world_helmet_runtime_policy().get(
		"hairAppearance", {}
	)
	return value if value is Dictionary else {}


static func actor_visual_layer_order(direction_row: int) -> Array[StringName]:
	# Wall fronts and actors only Y-sort when their final z_index matches. Keep
	# every wear layer on Z=0 and express classic equipment overlap by sibling
	# tree order inside the actor subtree.
	if weapon_draws_behind_actor(direction_row):
		return [
			ACTOR_VISUAL_WEAPON_LAYER,
			ACTOR_VISUAL_BODY_LAYER,
			ACTOR_VISUAL_HAIR_LAYER,
			ACTOR_VISUAL_HELMET_LAYER,
		]
	return [
		ACTOR_VISUAL_BODY_LAYER,
		ACTOR_VISUAL_HAIR_LAYER,
		ACTOR_VISUAL_WEAPON_LAYER,
		ACTOR_VISUAL_HELMET_LAYER,
	]


static func max_wear_weight(profession: String, level: int) -> int:
	return ProfessionRules.base_stat_for_level(profession, level, "max_wear_weight")


static func max_hand_weight(profession: String, level: int) -> int:
	return ProfessionRules.base_stat_for_level(profession, level, "max_hand_weight")


static func max_bag_weight(profession: String, level: int) -> int:
	return ProfessionRules.base_stat_for_level(profession, level, "max_bag_weight")


static func attribute_source_distribution(item: Dictionary) -> String:
	var source: Variant = item.get("source", ATTRIBUTE_MASTER_DISTRIBUTION)
	if source is Dictionary:
		return str(source.get("distribution", ATTRIBUTE_MASTER_DISTRIBUTION))
	return str(source)


static func requirement_for(item: Dictionary) -> Dictionary:
	if item.has("requirementType") and item.has("requirementValue"):
		var master_type := str(item.get("requirementType", "level"))
		return {
			"type": int(REQUIREMENT_TYPE_CODES.get(master_type, -1)),
			"type_id": master_type,
			"value": maxi(0, int(item.get("requirementValue", 0))),
			"source": attribute_source_distribution(item),
			"contract_id": str(item.get("attributeSource", {}).get("contractId", ATTRIBUTE_MASTER_CONTRACT_ID)),
			"confidence": "A",
		}
	if item.has("legacyNeed") and item.has("legacyNeedLevel"):
		var legacy_type := int(item.get("legacyNeed", NEED_LEVEL))
		return {
			"type": legacy_type,
			"type_id": str(REQUIREMENT_TYPE_CODES.find_key(legacy_type)),
			"value": maxi(0, int(item.get("legacyNeedLevel", 0))),
			"source": attribute_source_distribution(item),
			"contract_id": str(item.get("attributeSource", {}).get("contractId", ATTRIBUTE_MASTER_CONTRACT_ID)),
			"confidence": "A",
		}
	if item.has("serviceNeed") and item.has("serviceNeedLevel"):
		return {
			"type": int(item.get("serviceNeed", NEED_LEVEL)),
			"value": maxi(0, int(item.get("serviceNeedLevel", 0))),
			"source": "服务端StdItems",
			"confidence": "A",
		}
	for field: String in ["reqAttack", "reqMagic", "reqTao"]:
		var value: Variant = item.get(field, null)
		if value == null or int(value) <= 0:
			continue
		var need_type: int = int({"reqAttack": NEED_ATTACK, "reqMagic": NEED_MAGIC, "reqTao": NEED_TAO}[field])
		return {"type": need_type, "value": int(value), "source": "现有目录候选字段", "confidence": str(item.get("confidence", "B"))}
	return {
		"type": NEED_LEVEL,
		"value": maxi(0, int(item.get("reqLevel", 0) if item.get("reqLevel", null) != null else 0)),
		"source": "现有目录候选字段",
		"confidence": str(item.get("confidence", "B")),
	}


static func requirement_error(item: Dictionary, level: int, stats: Dictionary) -> String:
	var requirement := requirement_for(item)
	var need_type := int(requirement.get("type", NEED_LEVEL))
	var required := int(requirement.get("value", 0))
	match need_type:
		NEED_LEVEL:
			return "" if level >= required else "需要等级%d" % required
		NEED_ATTACK:
			return "" if int(stats.get("attack_max", 0)) >= required else "需要攻击%d" % required
		NEED_MAGIC:
			return "" if int(stats.get("magic_max", 0)) >= required else "需要魔法%d" % required
		NEED_TAO:
			return "" if int(stats.get("tao_max", 0)) >= required else "需要道术%d" % required
		_:
			return "尚未支持服务端装备需求类型%d" % need_type


static func requirement_label(item: Dictionary) -> String:
	var requirement := requirement_for(item)
	var labels := {NEED_LEVEL: "等级", NEED_ATTACK: "攻击", NEED_MAGIC: "魔法", NEED_TAO: "道术"}
	var need_type := int(requirement.get("type", NEED_LEVEL))
	var label := str(labels.get(need_type, "类型%d" % need_type))
	return "%s%d（%s/%s）" % [label, int(requirement.get("value", 0)), str(requirement.get("source", "未知来源")), str(requirement.get("confidence", "?"))]


static func reference_price(item: Dictionary) -> int:
	return GameData.get_item_shop_price(item)


static func repair_cost(item: Dictionary, durability: int, max_durability: int) -> int:
	var equipment_catalog := item.duplicate(true)
	equipment_catalog["kind"] = "equipment"
	var quote := preload("res://scripts/pricing_service.gd").quote_repair(
		GameData.get_item_price_record(item),
		equipment_catalog,
		{
			"name": str(item.get("name", "")),
			"durability": durability,
			"max_durability": max_durability,
		}
	)
	return int(quote.get("total_price", 0)) if bool(quote.get("valid", false)) else 0


static func blessing_outcome(luck: int, curse: int, attack_min: int, attack_max: int, unlucky_roll: int, success_roll: int, upper_stage_roll := -1) -> Dictionary:
	var state := weapon_luck_state({"weapon_luck": luck, "weapon_curse": curse})
	var next_luck := int(state.luck)
	var next_curse := int(state.curse)
	if blessing_is_unlucky_roll(unlucky_roll):
		if next_luck > 0:
			next_luck -= 1
		elif next_curse < MAX_WEAPON_CURSE:
			next_curse += 1
		return {"result": "cursed", "luck": next_luck, "curse": next_curse}
	if next_curse > 0:
		next_curse -= 1
		return {"result": "improved", "luck": next_luck, "curse": next_curse}
	if next_luck < LUCK_POINT_1:
		return {"result": "improved", "luck": next_luck + 1, "curse": next_curse}
	var span_factor := blessing_span_factor(attack_min, attack_max)
	if next_luck < LUCK_POINT_2:
		var denominator := span_factor + LUCK_POINT_2_RATE
		if denominator > 1 and success_roll == 1:
			return {"result": "improved", "luck": next_luck + 1, "curse": next_curse}
		# Original WeaptonMakeLuck chains complete conditions with else-if.
		# A failed lower-stage roll therefore reaches the independent upper roll.
		if upper_stage_roll == 1:
			return {"result": "improved", "luck": next_luck + 1, "curse": next_curse}
	elif next_luck < LUCK_POINT_3:
		var denominator := span_factor * LUCK_POINT_3_RATE
		if denominator > 1 and success_roll == 1:
			return {"result": "improved", "luck": next_luck + 1, "curse": next_curse}
	return {"result": "ineffective", "luck": next_luck, "curse": next_curse}


static func blessing_is_unlucky_roll(unlucky_roll: int) -> bool:
	return unlucky_roll == 1


static func blessing_span_factor(attack_min: int, attack_max: int) -> int:
	# The source calculates floor(abs(DCmax - DCmin) / 5). The authorized
	# boundary revision clamps R to one so Random(R * 40) remains reachable
	# for equal/narrow attack ranges such as 命运之刃 12—16.
	return maxi(1, int(absi(attack_max - attack_min) / 5))


static func blessing_success_denominator(luck: int, attack_min: int, attack_max: int) -> int:
	var span_factor := blessing_span_factor(attack_min, attack_max)
	if luck < LUCK_POINT_1:
		return 1
	if luck < LUCK_POINT_2:
		return span_factor + LUCK_POINT_2_RATE
	if luck < LUCK_POINT_3:
		return span_factor * LUCK_POINT_3_RATE
	return 0


static func equipment_luck_contribution(item: Dictionary, instance: Dictionary = {}, include_weapon_instance := false) -> int:
	var item_luck := int(item.get("luck", 0)) if item.get("luck", null) != null else 0
	var item_curse := int(item.get("curse", 0)) if item.get("curse", null) != null else 0
	var instance_luck := int(instance.get("weapon_luck", 0)) if include_weapon_instance else 0
	var instance_curse := int(instance.get("weapon_curse", 0)) if include_weapon_instance else 0
	return item_luck - item_curse + instance_luck - instance_curse


static func weapon_luck_label(instance: Dictionary) -> String:
	var state := weapon_luck_state(instance)
	if int(state.luck) > 0:
		return "幸运+%d" % int(state.luck)
	if int(state.curse) > 0:
		return "诅咒+%d" % int(state.curse)
	return ""


static func weapon_luck_state(instance: Dictionary) -> Dictionary:
	# Legacy saves may contain both fields. Preserve their effective difference;
	# new oil mutations write an exclusive pair instead of inventing a bonus.
	var net := clampi(int(instance.get("weapon_luck", 0)), 0, LUCK_POINT_3) - clampi(int(instance.get("weapon_curse", 0)), 0, MAX_WEAPON_CURSE)
	return {"luck": maxi(0, net), "curse": maxi(0, -net)}


static func special_effect_for(item: Dictionary) -> Dictionary:
	if item.has("specialEffect"):
		var configured: Variant = item.get("specialEffect", {})
		if not configured is Dictionary or configured.is_empty():
			return {}
		var result: Dictionary = configured.duplicate(true)
		result["mapping_source"] = str(item.get("customizationSource", "装备数据字段specialEffect"))
		return result
	if item.has("serviceAniCount"):
		var code := int(item.get("serviceAniCount", 0))
		for effect: Dictionary in SPECIAL_EFFECTS_BY_NAME.values():
			if int(effect.get("source_code", -1)) == code:
				var exact := effect.duplicate(true)
				exact["confidence"] = "A"
				exact["mapping_source"] = "服务端StdItems.AniCount"
				return exact
	var by_name: Dictionary = SPECIAL_EFFECTS_BY_NAME.get(str(item.get("name", "")), {})
	if by_name.is_empty():
		var set_piece := set_piece_for(item)
		if set_piece.is_empty():
			return {}
		return {
			"id": "%s_piece" % set_piece.get("set", "set"),
			"label": "%s组件" % ("魔血" if set_piece.get("set", "") == "magic_blood" else "虹魔"),
			"runtime": true,
			"confidence": "B",
			"mapping_source": "服务端Shape公式 + 项目候选AniCount",
		}
	var candidate := by_name.duplicate(true)
	candidate["mapping_source"] = "装备名称候选·待StdItems.AniCount复核"
	return candidate


static func set_piece_for(item: Dictionary) -> Dictionary:
	if item.has("setPiece"):
		var configured: Variant = item.get("setPiece", {})
		if not configured is Dictionary or configured.is_empty():
			return {}
		var configured_result: Dictionary = configured.duplicate(true)
		configured_result["power_source"] = str(item.get("customizationSource", "装备数据字段setPiece"))
		return configured_result
	var piece: Dictionary = SET_PIECES_BY_NAME.get(str(item.get("name", "")), {})
	if piece.is_empty():
		return {}
	var result := piece.duplicate(true)
	result["power_source"] = "serviceAniCount" if item.has("serviceAniCount") else "项目候选·待StdItems.AniCount替换"
	if item.has("serviceAniCount"):
		result["power"] = int(item.get("serviceAniCount", result.get("power", 0)))
	return result


static func effective_profession(item: Dictionary) -> String:
	if not set_piece_for(item).is_empty():
		return "通用"
	if item.has("jobLock"):
		var job_lock: Variant = item.get("jobLock", null)
		if job_lock == null or str(job_lock).is_empty():
			return "通用"
		return str(JOB_LOCK_DISPLAY_NAMES.get(str(job_lock), str(job_lock)))
	if item.has("jobAffinity"):
		# jobAffinity is descriptive only. Absence of an explicit jobLock means
		# classic universal equipping after requirements and weight are met.
		return "通用"
	return str(item.get("profession", "通用"))


static func special_action_label(effect_id: String) -> String:
	return {"teleport": "传送", "flame_skill": "火球", "recovery_skill": "治愈"}.get(effect_id, effect_id)


static func paralysis_succeeds(target_anti_poison: int, roll: int) -> bool:
	var denominator := maxi(1, target_anti_poison + 5)
	return clampi(roll, 0, denominator - 1) == 0


static func critical_succeeds(chance: float, roll: float) -> bool:
	return clampf(roll, 0.0, 0.999999) < clampf(chance, 0.0, 1.0)


static func critical_damage(damage: int, multiplier: float) -> int:
	return maxi(1, int(round(float(maxi(1, damage)) * maxf(1.0, multiplier))))


static func required_gender(item: Dictionary) -> String:
	if item.has("genderRestriction"):
		var restriction: Variant = item.get("genderRestriction", null)
		if restriction == null or str(restriction).is_empty():
			return ""
		return str({"male": "男", "female": "女"}.get(str(restriction), str(restriction)))
	var std_mode := int(item.get("serviceStdMode", -1))
	if std_mode == 10:
		return "男"
	if std_mode == 11:
		return "女"
	var name := str(item.get("name", ""))
	if name.ends_with("(男)"):
		return "男"
	if name.ends_with("(女)"):
		return "女"
	return ""


static func weight_requirement_for(item: Dictionary) -> Dictionary:
	if item.has("weightRequirementType") and item.has("weightRequirementValue"):
		return {
			"type": str(item.get("weightRequirementType", "")),
			"value": maxi(0, int(item.get("weightRequirementValue", 0))),
			"source": attribute_source_distribution(item),
		}
	var legacy_type := "hand" if ItemCategories.category_for_record(item) == "hc.item_category.weapon" else "wear"
	return {
		"type": legacy_type,
		"value": maxi(0, int(item.get("weight", 0))),
		"source": "legacy_weight_compatibility",
	}


static func legacy_range_warning(field: String, min_value: int, max_value: int) -> Dictionary:
	if min_value <= max_value:
		return {}
	return {
		"warningCode": "legacy_reverse_range",
		"field": field,
		"min": min_value,
		"max": max_value,
		"runtimeBehavior": LEGACY_ROLL_POLICY,
		"isError": false,
	}


static func enrich_catalog_record(item: Dictionary) -> Dictionary:
	var result := item.duplicate(true)
	result["serviceRequirement"] = requirement_for(result)
	result["fieldSemanticsSource"] = "M2Server/Common/Grobal2.pas:TStdItem + M2Server/ObjBase.pas:CanUseItem"
	result["concreteStdItemsStatus"] = "项目装备属性主表已接入" if result.has("requirementType") else ("已接入" if result.has("serviceNeed") else "数据库缺失·保留候选值")
	result["referencePrice"] = reference_price(result)
	result["referencePriceSource"] = "server.crystal.cjlaaa:Server.MirDB:StdItem.Price" if int(result.get("referencePrice", 0)) > 0 else "missing_primary_price"
	var special := special_effect_for(result)
	if not special.is_empty():
		result["specialEffect"] = special
	return result


# ── equipment.skill_level_affix.v1 ──────────────────────────────────────────
# Canonical affix formats (all values are finite non-negative integers):
#   {stat:"skill_level", scope:"all", value:N}
#   {stat:"skill_level", scope:"profession:taoist", value:N}
#   {stat:"skill_level", scope:"skill:taoist.healing", value:N}
# Legacy formats remain readable and are converted explicitly:
#   {stat:"skill_level", op:"add", value:N, skill:"烈火剑法"}
#   {stat:"skill_level", op:"add", value:N, target:"烈火剑法"}
#   modifiers.skillLevels = {"all":1, "烈火剑法":2}
# The equipment layer never copies the skill catalog. Display-name scopes are
# returned under `legacy` so integration can convert them through the unique
# SkillDataLoader. The API only produces non-negative contributions; it does
# not grant unlearned skills (that decision belongs to PlayerState/skills).


static func skill_level_affix_contributions(record: Dictionary) -> Dictionary:
	var result := _empty_skill_level_affix_result()
	var modifiers: Variant = record.get("modifiers", null)
	if modifiers == null:
		return result
	if modifiers is Array:
		for index in range(modifiers.size()):
			var entry: Variant = modifiers[index]
			if not entry is Dictionary:
				_append_rejected(result, index, "array", "malformed_record", "技能等级词条必须是对象", entry)
				continue
			_absorb_parse_result(
				result,
				_parse_array_skill_level_affix(entry),
				index,
				"array",
				entry
			)
		return result
	if modifiers is Dictionary:
		var skill_levels: Variant = modifiers.get("skillLevels", null)
		if skill_levels == null:
			return result
		if not skill_levels is Dictionary:
			_append_rejected(result, -1, "skillLevels", "malformed_skill_levels", "skillLevels必须是对象", skill_levels)
			return result
		for raw_key: Variant in skill_levels:
			var key := str(raw_key)
			var value: Variant = skill_levels[raw_key]
			_absorb_parse_result(
				result,
				_parse_skill_level_pair(key, value),
				-1,
				"skillLevels",
				{"key": key, "value": value}
			)
		return result
	_append_rejected(result, -1, "modifiers", "unsupported_modifiers_container", "modifiers必须是数组或对象", modifiers)
	return result


static func aggregate_skill_level_affix_records(records: Array) -> Dictionary:
	var result := _empty_skill_level_affix_result()
	for record_index in range(records.size()):
		var record: Variant = records[record_index]
		if not record is Dictionary:
			result["rejected"] = int(result.get("rejected", 0)) + 1
			result["diagnostics"].append({
				"index": record_index,
				"source": "records",
				"code": "malformed_record",
				"message": "装备记录必须是对象",
				"record": record,
			})
			continue
		_merge_skill_level_affix_result(
			result,
			skill_level_affix_contributions(record),
			record_index
		)
	return result


static func parse_skill_level_affix_entry(entry: Dictionary) -> Dictionary:
	return _parse_array_skill_level_affix(entry)


static func _empty_skill_level_affix_result() -> Dictionary:
	return {
		"contractId": SKILL_LEVEL_AFFIX_CONTRACT_ID,
		"contributions": {},
		"legacy": {},
		"diagnostics": [],
		"accepted": 0,
		"rejected": 0,
	}


static func _parse_array_skill_level_affix(entry: Dictionary) -> Dictionary:
	if not entry.has("stat") or entry.get("stat") == null:
		return {"status": "rejected", "code": "missing_stat", "message": "技能等级词条缺少stat字段"}
	if str(entry.get("stat", "")) != SKILL_LEVEL_AFFIX_STAT:
		return {"status": "skipped", "code": "not_skill_level_affix"}
	if entry.has("op") and str(entry.get("op", "")) != "add":
		return {"status": "rejected", "code": "unsupported_op", "message": "技能等级词条只支持add或省略op"}
	var scope_result := _resolve_skill_level_scope(entry)
	if str(scope_result.get("status", "")) != "ok":
		return scope_result
	var value_result := _validate_skill_level_value(entry.get("value"))
	if not bool(value_result.get("ok", false)):
		return value_result
	var parsed := {
		"status": "accepted",
		"canonical_scope": str(scope_result.get("canonical_scope", "")),
		"value": int(value_result.get("value", 0)),
	}
	if scope_result.has("legacy_name"):
		parsed["status"] = "legacy"
		parsed["legacy_name"] = str(scope_result.get("legacy_name", ""))
		parsed.erase("canonical_scope")
	return parsed


static func _parse_skill_level_pair(key: String, value: Variant) -> Dictionary:
	var scope_result := _canonical_scope_from_pair_key(key)
	if str(scope_result.get("status", "")) != "ok":
		return scope_result
	var value_result := _validate_skill_level_value(value)
	if not bool(value_result.get("ok", false)):
		return value_result
	var parsed := {"status": "accepted", "value": int(value_result.get("value", 0))}
	if scope_result.has("canonical_scope"):
		parsed["canonical_scope"] = str(scope_result.get("canonical_scope", ""))
	else:
		parsed["status"] = "legacy"
		parsed["legacy_name"] = str(scope_result.get("legacy_name", ""))
	return parsed


static func _resolve_skill_level_scope(entry: Dictionary) -> Dictionary:
	var has_scope := entry.has("scope")
	var has_skill := entry.has("skill")
	var has_target := entry.has("target")
	if has_scope and (has_skill or has_target):
		return {"status": "rejected", "code": "conflicting_scope_fields", "message": "scope与skill/target不能同时出现"}
	if not has_scope:
		if has_skill or has_target:
			var raw: Variant = entry.get("skill", entry.get("target", null))
			if raw == null or not raw is String:
				return {"status": "rejected", "code": "invalid_legacy_scope", "message": "legacy技能名必须是字符串"}
			return _canonical_scope_from_pair_key(str(raw))
		return {"status": "ok", "canonical_scope": SKILL_LEVEL_SCOPE_ALL}
	var raw_scope: Variant = entry.get("scope")
	if not raw_scope is String:
		return {"status": "rejected", "code": "invalid_scope", "message": "scope必须是字符串"}
	var scope := str(raw_scope)
	if scope == SKILL_LEVEL_SCOPE_ALL:
		return {"status": "ok", "canonical_scope": SKILL_LEVEL_SCOPE_ALL}
	if scope.begins_with(SKILL_LEVEL_SCOPE_PREFIX_PROFESSION):
		var profession := scope.substr(SKILL_LEVEL_SCOPE_PREFIX_PROFESSION.length())
		if profession not in SKILL_LEVEL_PROFESSIONS:
			return {"status": "rejected", "code": "invalid_profession_scope", "message": "profession只允许warrior/wizard/taoist"}
		return {"status": "ok", "canonical_scope": scope}
	if scope.begins_with(SKILL_LEVEL_SCOPE_PREFIX_SKILL):
		var skill_id := scope.substr(SKILL_LEVEL_SCOPE_PREFIX_SKILL.length())
		if not _looks_like_stable_skill_id(skill_id):
			return {"status": "rejected", "code": "invalid_skill_scope", "message": "skill后必须是稳定技能ID"}
		return {"status": "ok", "canonical_scope": scope}
	return {"status": "rejected", "code": "invalid_scope", "message": "scope格式不支持"}


static func _canonical_scope_from_pair_key(key: String) -> Dictionary:
	if key.is_empty():
		return {"status": "rejected", "code": "invalid_legacy_scope", "message": "legacy技能名不能为空"}
	if key == SKILL_LEVEL_SCOPE_ALL:
		return {"status": "ok", "canonical_scope": SKILL_LEVEL_SCOPE_ALL}
	if _looks_like_stable_skill_id(key):
		return {"status": "ok", "canonical_scope": SKILL_LEVEL_SCOPE_PREFIX_SKILL + key}
	return {"status": "ok", "legacy_name": key}


static func _validate_skill_level_value(value: Variant) -> Dictionary:
	if value == null:
		return {"status": "rejected", "code": "missing_value", "message": "技能等级词条缺少value"}
	if value is int:
		var integer := int(value)
		if integer <= 0:
			return {"status": "rejected", "code": "non_positive_value", "message": "技能等级词条必须是正数"}
		return {"ok": true, "value": integer}
	if value is float:
		var number := float(value)
		if not is_finite(number):
			return {"status": "rejected", "code": "non_finite_value", "message": "技能等级value必须是有限数值"}
		if floorf(number) != number:
			return {"status": "rejected", "code": "non_integer_value", "message": "技能等级value必须是整数语义"}
		if number <= 0.0:
			return {"status": "rejected", "code": "non_positive_value", "message": "技能等级词条必须是正数"}
		return {"ok": true, "value": int(number)}
	return {"status": "rejected", "code": "invalid_value_type", "message": "技能等级value必须是整数或整数语义浮点"}


static func _absorb_parse_result(result: Dictionary, parsed: Dictionary, index: int, source: String, raw_record: Variant) -> void:
	var status := str(parsed.get("status", "rejected"))
	if status == "accepted":
		_accumulate_skill_level_value(
			result,
			"contributions",
			str(parsed.get("canonical_scope", "")),
			int(parsed.get("value", 0)),
			index,
			source
		)
		result["accepted"] = int(result.get("accepted", 0)) + 1
		return
	if status == "legacy":
		_accumulate_skill_level_value(
			result,
			"legacy",
			str(parsed.get("legacy_name", "")),
			int(parsed.get("value", 0)),
			index,
			source
		)
		result["accepted"] = int(result.get("accepted", 0)) + 1
		result["diagnostics"].append({
			"index": index,
			"source": source,
			"code": "legacy_display_name_scope",
			"message": "legacy技能名由integration经SkillDataLoader转换为稳定ID后接入玩家状态",
		})
		return
	if status == "skipped":
		return
	_append_rejected(
		result,
		index,
		source,
		str(parsed.get("code", "invalid_record")),
		str(parsed.get("message", "无效技能等级词条")),
		raw_record
	)


static func _accumulate_skill_level_value(result: Dictionary, bucket: String, key: String, value: int, index: int, source: String) -> void:
	var container: Dictionary = result.get(bucket, {})
	var current := int(container.get(key, 0))
	var next := current
	if value > 0 and current > SKILL_LEVEL_INT64_MAX - value:
		next = SKILL_LEVEL_INT64_MAX
		result["diagnostics"].append({
			"index": index,
			"source": source,
			"code": "overflow_guard_clamped",
			"message": "技能等级贡献累加超过int64技术上限，已钳制到最大值（非玩法上限）",
		})
	else:
		next = current + value
	container[key] = next
	result[bucket] = container


static func _merge_skill_level_affix_result(result: Dictionary, partial: Dictionary, record_index: int) -> void:
	for scope_key: Variant in partial.get("contributions", {}):
		_accumulate_skill_level_value(
			result,
			"contributions",
			str(scope_key),
			int(partial["contributions"][scope_key]),
			record_index,
			"aggregate"
		)
	for legacy_key: Variant in partial.get("legacy", {}):
		_accumulate_skill_level_value(
			result,
			"legacy",
			str(legacy_key),
			int(partial["legacy"][legacy_key]),
			record_index,
			"aggregate"
		)
	result["accepted"] = int(result.get("accepted", 0)) + int(partial.get("accepted", 0))
	result["rejected"] = int(result.get("rejected", 0)) + int(partial.get("rejected", 0))
	for diagnostic: Variant in partial.get("diagnostics", []):
		if not diagnostic is Dictionary:
			continue
		var merged: Dictionary = diagnostic.duplicate(true)
		merged["recordIndex"] = record_index
		result["diagnostics"].append(merged)


static func _append_rejected(result: Dictionary, index: int, source: String, code: String, message: String, raw_record: Variant) -> void:
	result["diagnostics"].append({
		"index": index,
		"source": source,
		"code": code,
		"message": message,
		"record": raw_record.duplicate(true) if raw_record is Dictionary else raw_record,
	})
	result["rejected"] = int(result.get("rejected", 0)) + 1


static func _looks_like_stable_skill_id(value: String) -> bool:
	if value.is_empty() or value.length() > SKILL_LEVEL_STABLE_ID_MAX_LENGTH:
		return false
	if not _is_stable_id_ascii_alnum(value.unicode_at(0)):
		return false
	for index in range(1, value.length()):
		var code := value.unicode_at(index)
		if not (_is_stable_id_ascii_alnum(code) or code == 46 or code == 95 or code == 45):
			return false
	return true


static func _is_stable_id_ascii_alnum(code: int) -> bool:
	return (code >= 48 and code <= 57) or (code >= 97 and code <= 122)
