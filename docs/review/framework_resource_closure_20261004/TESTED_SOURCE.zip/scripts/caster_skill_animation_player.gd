class_name CasterSkillAnimationPlayer
extends Sprite2D

const TrialScreenShader := preload("res://assets/shaders/trial_magic_screen.gdshader")
const FireWallMultiplyShader := preload("res://assets/shaders/fire_wall_screen_blend_multiply.gdshader")
const FORWARD_ENDPOINT_FIT_CONTRACT_ID := (
	"skills.caster.line_visual.forward_endpoint_uniform.v1"
)
const AXIS_CROSS_FIT_CONTRACT_ID := (
	"skills.caster.line_visual.frame_alpha_cross_affine.v3"
)
signal animation_finished(skill_id: String)
signal skill_frame_changed(frame_index: int)

var skill_id := ""
var phase_id := ""
var visual_loaded := false
var playback_complete := false
var current_frame_index := 0
var direction_index := 0

var _frames: Array[Dictionary] = []
var _frame_time_seconds := 0.05
var _elapsed := 0.0
var _loop := false
var _manual_mode := false
var _batched_playback := false
## R14-C3/C4 + R14-C-R2: active-sequence residency lease + wait state.
## _sequence_paths is the ONE selected direction's frame paths. Combat plays
## a sequence as an ATOMIC unit: a first-frame miss AND a partial-residency
## miss keep the player alive waiting for the WHOLE sequence (no early frame
## 0, no logical-clock start) instead of permanently stopping, and a
## mid-sequence miss freezes the logical clock without skipping a frame.
## R14-C-R1 P0-4/5/6/7: _sequence_lease_held is the ownership truth - a
## waiter that has never acquired must never decrement the registry refcount
## (no phantom release of another owner's lease), and retry must not stack a
## second refcount after an acquire.
var _sequence_paths: Array[String] = []
var _sequence_lease_held := false
var _waiting_for_residency := false
var _native_extent := 1.0
var _desired_extent := 0.0
var _desired_footprint := Vector2.ZERO
var _desired_axis_extent := 0.0
var _desired_cross_axis_extent := 0.0
var _fit_axis_world := Vector2.ZERO
var _source_axis_local := Vector2.UP
var _source_cross_axis_local := Vector2.RIGHT
var _anchor_policy := "top_left_from_world_anchor"
var _sequence_bounds := Rect2()
var _sequence_anchor_rebase := Vector2.ZERO
var _axis_cross_fit_active := false
var _longitudinal_scale := 1.0
var _target_cross_axis := Vector2.RIGHT
var _trial_screen_copy: BackBufferCopy
var _fire_wall_additive_sprite: Sprite2D


func _ready() -> void:
	_ensure_trial_screen_copy()
	visibility_changed.connect(_sync_trial_screen_copy_visibility)


func _ensure_trial_screen_copy() -> void:
	if material == null or is_instance_valid(_fire_wall_additive_sprite) or not is_inside_tree() or get_parent() == null:
		return
	if is_instance_valid(_trial_screen_copy):
		_sync_trial_screen_copy_visibility()
		return
	# Own the copy as a child drawn immediately before this sprite. Adding a
	# sibling during _ready can fail while the parent enters its children.
	# The same relative Z lane preserves capture after earlier world items.
	_trial_screen_copy = BackBufferCopy.new()
	_trial_screen_copy.name = "TrialScreenBackdrop"
	_trial_screen_copy.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
	_trial_screen_copy.z_as_relative = true
	_trial_screen_copy.z_index = 0
	_trial_screen_copy.show_behind_parent = true
	add_child(_trial_screen_copy)
	_sync_trial_screen_copy_visibility()


func _sync_trial_screen_copy_visibility() -> void:
	if is_instance_valid(_trial_screen_copy):
		_trial_screen_copy.visible = visible and texture != null


func configure(
	source_skill_id: String,
	direction := Vector2.DOWN,
	desired_extent := 0.0,
	loop_override: Variant = null,
	requested_phase_id := "",
	desired_footprint := Vector2.ZERO,
	desired_axis_extent := 0.0,
	fit_axis_world := Vector2.ZERO,
	desired_cross_axis_extent := 0.0,
	presentation_overrides: Dictionary = {}
) -> bool:
	# R14-C5: release the previous sequence lease before reconfigure.
	_release_sequence_lease()
	skill_id = ProfessionRules.skill_id(source_skill_id)
	phase_id = requested_phase_id
	visual_loaded = false
	playback_complete = false
	_waiting_for_residency = false
	_sequence_lease_held = false
	texture = null
	transform = Transform2D.IDENTITY
	offset = Vector2.ZERO
	_sequence_anchor_rebase = Vector2.ZERO
	_axis_cross_fit_active = false
	_longitudinal_scale = 1.0
	_target_cross_axis = Vector2.RIGHT
	set_process(false)
	if not CasterSkillVisualRegistry.is_runtime_ready(skill_id):
		return false
	var profile := CasterSkillVisualRegistry.profile(skill_id)
	material = null
	if is_instance_valid(_trial_screen_copy):
		_trial_screen_copy.hide()
		_trial_screen_copy.queue_free()
		_trial_screen_copy = null
	if is_instance_valid(_fire_wall_additive_sprite):
		_fire_wall_additive_sprite.queue_free()
		_fire_wall_additive_sprite = null
	var original_path := str(profile.get("original_path", "")).to_lower()
	if not profile.has("user_visual_override") and (
		original_path.ends_with("magic.wil")
		or original_path.ends_with("magic2.wil")
	):
		if skill_id == "wizard.fire_wall":
			# Screen(B, S, a) = B * (1 - a*S) + a*S. Draw the
			# multiplication and addition in order for each cell, avoiding
			# a full-viewport BackBufferCopy per fire-wall visual.
			var multiply_material := ShaderMaterial.new()
			multiply_material.shader = FireWallMultiplyShader
			material = multiply_material
			_fire_wall_additive_sprite = Sprite2D.new()
			_fire_wall_additive_sprite.name = "FireWallAdditive"
			_fire_wall_additive_sprite.centered = centered
			_fire_wall_additive_sprite.texture_filter = texture_filter
			var additive_material := CanvasItemMaterial.new()
			additive_material.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
			_fire_wall_additive_sprite.material = additive_material
			add_child(_fire_wall_additive_sprite)
		else:
			var trial_material := ShaderMaterial.new()
			trial_material.shader = TrialScreenShader
			material = trial_material
	_ensure_trial_screen_copy()
	var animation := CasterSkillVisualRegistry.animation_profile(skill_id, phase_id)
	if animation.get("contract", "") != "caster_skill_animation.v1":
		return false
	var sequences: Array = animation.get("sequences", [])
	if sequences.is_empty():
		return false
	direction_index = CasterSkillVisualRegistry.direction_index(direction) if int(animation.get("direction_count", 1)) > 1 else 0
	var selected: Dictionary = sequences[
		CasterSkillVisualRegistry.sequence_index(direction_index, sequences)
	]
	_frames.assign(selected.get("frames", []))
	if _frames.is_empty():
		return false
	_frame_time_seconds = maxf(0.001, float(animation.get("frame_time_ms", 50)) / 1000.0)
	_loop = bool(animation.get("playback", "once") == "loop")
	if loop_override is bool:
		_loop = bool(loop_override)
	var render := CasterSkillVisualRegistry.render_policy(skill_id, phase_id)
	var visual_type := CasterSkillVisualRegistry.visual_type(skill_id)
	var visual_width_scale := maxf(
		0.001,
		float(
			render.get(
				"visual_width_scale",
				render.get("source_scale_x", 1.0)
			)
		)
	)
	var visual_height_scale := maxf(
		0.001,
		float(
			render.get(
				"visual_height_scale",
				render.get("source_scale_y", 1.0)
			)
		)
	)
	_anchor_policy = str(presentation_overrides.get("anchor_policy", str(render.get("anchor_policy", "top_left_from_world_anchor"))))
	_sequence_bounds = _visual_bounds_for_frames(_frames, _anchor_policy)
	# Compute source axis before anchor rebase so the new policy can use it.
	var fallback_source_axis := Vector2.UP.rotated(
		float(direction_index) * TAU / 16.0
	).normalized()
	_source_axis_local = _vector2_pair(
		selected.get("source_axis_local", []), fallback_source_axis
	).normalized()
	_source_cross_axis_local = Vector2(
		-_source_axis_local.y, _source_axis_local.x
	)
	if _anchor_policy == "align_sequence_visible_axis_start_to_geometry_origin":
		_apply_frame_source_axis(_frames[0])
		_sequence_anchor_rebase = _visible_axis_anchor_rebase(
			_frames[0], _rebase_to_visible_axis_start(_sequence_bounds)
		)
	elif _anchor_policy == "center_sequence_bounds_on_geometry_origin":
		_sequence_anchor_rebase = -_sequence_bounds.get_center()
	else:
		_sequence_anchor_rebase = Vector2.ZERO
	var explicit_anchor_rebase: Array = render.get(
		"anchor_rebase_pixels", [0.0, 0.0]
	)
	if explicit_anchor_rebase.size() >= 2:
		_sequence_anchor_rebase += Vector2(
			float(explicit_anchor_rebase[0]),
			float(explicit_anchor_rebase[1])
		)
	_native_extent = maxf(
		1.0,
		maxf(_sequence_bounds.size.x, _sequence_bounds.size.y)
	)
	_desired_extent = maxf(0.0, desired_extent)
	_desired_footprint = Vector2(
		maxf(0.0, desired_footprint.x),
		maxf(0.0, desired_footprint.y)
	)
	_desired_axis_extent = maxf(0.0, desired_axis_extent)
	_desired_cross_axis_extent = maxf(0.0, desired_cross_axis_extent)
	_fit_axis_world = (
		fit_axis_world.normalized()
		if fit_axis_world.length_squared() > 0.000001
		else Vector2.ZERO
	)
	if visual_type == "sky_strike":
		var visual_profile: Dictionary = (
			CasterSkillVisualRegistry.visual_profile(skill_id)
		)
		var profile_animation: Dictionary = (
			visual_profile.get("animation", {}) as Dictionary
		)
		if str(profile_animation.get("scale_mode", "")) == "fixed_source":
			visual_width_scale = maxf(
				0.001,
				float(profile_animation.get("width_scale", visual_width_scale))
			)
			visual_height_scale = maxf(
				0.001,
				float(profile_animation.get("height_scale", visual_height_scale))
			)
		scale = Vector2(visual_width_scale, visual_height_scale)
	elif (
		_desired_axis_extent > 0.0
		and not _fit_axis_world.is_zero_approx()
	):
		# Mir16 selects the nearest available source artwork only. Its visible alpha
		# axis is measured per frame in source-anchor coordinates; mapping that real
		# basis onto the exact snapshot axis removes source-art quantization without
		# changing canonical gameplay geometry. Length and thickness are fitted from
		# the same frame's visible alpha envelope.
		var native_forward_extent := _frame_visible_axis_extent(_frames[0])
		if native_forward_extent <= 0.0:
			native_forward_extent = _rect_forward_projection_extent(
				_sequence_bounds, _sequence_anchor_rebase, _source_axis_local
			)
		_longitudinal_scale = (
			_desired_axis_extent / maxf(0.001, native_forward_extent)
		)
		if _desired_cross_axis_extent <= 0.0:
			# Beam profiles historically supplied only a geometry-owned length.
			# Preserve their first frame's native aspect ratio while still giving
			# every frame one explicit target cross extent to normalize against.
			_desired_cross_axis_extent = (
				_frame_visible_cross_extent(_frames[0]) * _longitudinal_scale
			)
		_target_cross_axis = Vector2(-_fit_axis_world.y, _fit_axis_world.x)
		_axis_cross_fit_active = true
		# Per-frame alpha calibration keeps the animated visible start, end and
		# centreline stable even when the source frame bounds change.
		_apply_axis_cross_transform(_frames[0])
	elif (
		_desired_axis_extent > 0.0
		and not _fit_axis_world.is_zero_approx()
	):
		var fallback_native_forward_extent := _rect_forward_projection_extent(
			_sequence_bounds, _sequence_anchor_rebase, _source_axis_local
		)
		scale = Vector2.ONE * (
			_desired_axis_extent / maxf(0.001, fallback_native_forward_extent)
		)
	elif (
		_desired_footprint.x > 0.0
		and _desired_footprint.y > 0.0
		and _sequence_bounds.size.x > 0.0
		and _sequence_bounds.size.y > 0.0
	):
		var contain_scale := minf(
			_desired_footprint.x / _sequence_bounds.size.x,
			_desired_footprint.y / _sequence_bounds.size.y
		)
		scale = Vector2.ONE * maxf(0.001, contain_scale)
	elif _desired_extent > 0.0:
		scale = Vector2.ONE * (_desired_extent / _native_extent)
	else:
		var source_scale := maxf(0.001, float(render.get("source_scale", 1.0)))
		scale = Vector2(
			source_scale * maxf(0.001, float(render.get("source_scale_x", 1.0))),
			source_scale * maxf(0.001, float(render.get("source_scale_y", 1.0)))
		)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	current_frame_index = 0
	_elapsed = 0.0
	_manual_mode = false
	playback_complete = false
	# R14-C3 + R14-C-R1 P0-1/P0-5: configure() returns whether the
	# configuration was ACCEPTED, not whether frame 0 is already resident.
	# Structural failures (unknown skill, bad contract, empty frames) return
	# false. A legal configuration whose texture sequence is still warming up
	# returns true with visual_loaded=false and _waiting_for_residency=true;
	# the production caller keeps the node and playback starts on residency.
	# The sequence lease is acquired through the helper (only when the whole
	# sequence is resident - never a phantom lease on missing paths).
	_sequence_paths = CasterSkillVisualRegistry.animation_sequence_paths(
		skill_id, direction_index, phase_id
	)
	# R14-C-R2 C-R2-1/2/3: combat plays a sequence as an ATOMIC unit. When
	# the loading window is closed and ANY frame of the sequence is missing,
	# the player must NOT show an already-resident frame 0, must not start
	# the logical clock and must not claim visual_loaded: it queues the
	# async warm and waits, then starts from frame 0 once the WHOLE sequence
	# is resident. Inside the loading window the pre-existing synchronous
	# semantics stay (request_animation_frame_texture resolves frame 0 -
	# and later frames - synchronously), and GameRoot's loading prewarm
	# makes whole workset sequences resident so the formal Loading->READY
	# path still reaches the full-resident branch below.
	if CasterSkillVisualRegistry.combat_sequence_requires_wait(_sequence_paths):
		CasterSkillVisualRegistry.queue_sequence_warm(_sequence_paths)
		_waiting_for_residency = true
		visual_loaded = false
		current_frame_index = 0
		_elapsed = 0.0
		texture = null
		set_process(true)
		return true
	# Combat full-resident or loading-window path: acquire the lease (only
	# when the whole sequence is resident - never a phantom lease) and try
	# frame 0 exactly like the pre-R14-C path.
	_acquire_sequence_lease_if_ready()
	visual_loaded = _apply_frame(0)
	if visual_loaded:
		_waiting_for_residency = false
		set_process(true)
	else:
		CasterSkillVisualRegistry.queue_sequence_warm(_sequence_paths)
		_waiting_for_residency = true
		set_process(true)
	return true


## R14-C-R1 P0-5: acquire the sequence lease exactly once. Already held ->
## true (no refcount stacking). Not fully resident -> false (waiter stays
## un-leased; the async warm-up channel fills the sequence without a lease).
func _acquire_sequence_lease_if_ready() -> bool:
	if _sequence_lease_held:
		return true
	if not CasterSkillVisualRegistry.acquire_sequence_lease(_sequence_paths):
		return false
	_sequence_lease_held = true
	return true


## R14-C-R1 P0-6: safe release. Only a real owner decrements the registry
## refcount; a never-acquired waiter must not release another owner's lease.
func _release_sequence_lease() -> void:
	if _sequence_lease_held:
		CasterSkillVisualRegistry.release_sequence_lease(_sequence_paths)
		_sequence_lease_held = false
	_sequence_paths.clear()


func _exit_tree() -> void:
	# R14-C5: looping/persistent effects hold the lease until node teardown;
	# one-shot players release on completion. Reconfigure and exit both
	# release here.
	_release_sequence_lease()


func _process(delta: float) -> void:
	if _batched_playback:
		return
	if _waiting_for_residency:
		# R14-C3/C4: hold the frame index and logical clock while the active
		# sequence warms up; resume from frame 0 (first-frame miss) or from
		# the last committed index (mid-sequence miss) once resident. This
		# must run even when visual_loaded is still false (first-frame miss).
		_retry_after_warm()
		return
	if not visual_loaded or playback_complete or _manual_mode:
		return
	# perf-smoothness-r1 C-R1 (PERF-R2 R19/Phase D first item): catch-up must
	# commit ONLY the final frame. A long frame (e.g. 100 ms) used to bind
	# every intermediate texture in one render frame; the player only ever
	# sees the last one, so compute the final index in closed form and apply
	# it once. Frame-index parity with small-delta playback is contract-tested.
	_elapsed += delta
	if _elapsed < _frame_time_seconds:
		return
	var steps := int(floor(_elapsed / _frame_time_seconds))
	_elapsed -= float(steps) * _frame_time_seconds
	if _loop:
		var loop_target := (
			(current_frame_index + steps) % _frames.size()
		)
		# R14-C4: commit the frame BEFORE advancing the index; a miss on a
		# leased sequence freezes the clock instead of skipping a frame.
		if _apply_frame(loop_target) or _sequence_paths.is_empty():
			current_frame_index = loop_target
		else:
			_handle_mid_sequence_miss()
		return
	var target_frame := current_frame_index + steps
	if target_frame >= _frames.size():
		target_frame = _frames.size() - 1
		if _apply_frame(target_frame) or _sequence_paths.is_empty():
			current_frame_index = target_frame
			playback_complete = true
			# R14-C5: one-shot completed - release the sequence lease.
			_release_sequence_lease()
			animation_finished.emit(skill_id)
		else:
			_handle_mid_sequence_miss()
		return
	if _apply_frame(target_frame) or _sequence_paths.is_empty():
		current_frame_index = target_frame
	else:
		_handle_mid_sequence_miss()


func _handle_mid_sequence_miss() -> void:
	# R14-C4: keep the last committed texture, freeze the logical clock and
	# queue the missing path. The frame index is NOT advanced while the
	# texture is uncommitted; playback resumes at the same index once the
	# sequence is resident again.
	CasterSkillVisualRegistry.queue_sequence_warm(_sequence_paths)
	_waiting_for_residency = true
	_elapsed = 0.0


func _retry_after_warm() -> void:
	if not CasterSkillVisualRegistry.sequence_resident(_sequence_paths):
		CasterSkillVisualRegistry.queue_sequence_warm(_sequence_paths)
		return
	# R14-C-R1 P0-7: acquire at most once. If _apply_frame below edge-fails
	# after a successful acquire, the lease is KEPT and the next retry sees
	# _sequence_lease_held==true - it must not stack a second refcount.
	_acquire_sequence_lease_if_ready()
	_waiting_for_residency = false
	_elapsed = 0.0
	# C3 first-frame miss: index is still 0 -> starts from frame 0.
	# C4 mid-sequence miss: index is the last committed frame -> continues
	# there without skipping a logical frame.
	visual_loaded = _apply_frame(current_frame_index)
	if not visual_loaded:
		# Edge: the sequence was resident a moment ago but the frame still
		# could not be committed. Never permanently stop the player (C3):
		# go back to waiting so the next process tick retries.
		_waiting_for_residency = true
		CasterSkillVisualRegistry.queue_sequence_warm(_sequence_paths)
		set_process(true)
		return
	set_process(true)


func animation_sequence_key() -> String:
	return "%s:%s:%d:%d:%f" % [skill_id, phase_id, direction_index, _frames.size(), _frame_time_seconds]


func is_looping_sequence() -> bool:
	return _loop and not _frames.is_empty()


func set_batched_playback(enabled: bool) -> void:
	_batched_playback = enabled
	set_process(not enabled)


func commit_batched_frame(frame_index: int) -> bool:
	if not _batched_playback or frame_index < 0 or frame_index >= _frames.size():
		return false
	if _waiting_for_residency:
		_retry_after_warm()
		# Residency recovery belongs to this batch, never a second process loop.
		set_process(false)
		if _waiting_for_residency or not visual_loaded:
			return false
	if visual_loaded and current_frame_index == frame_index:
		return true
	if not _apply_frame(frame_index):
		_handle_mid_sequence_miss()
		return false
	visual_loaded = true
	current_frame_index = frame_index
	return true


func set_manual_frame(frame_index: int) -> bool:
	if _frames.is_empty():
		return false
	_manual_mode = true
	playback_complete = false
	_elapsed = 0.0
	current_frame_index = clampi(frame_index, 0, _frames.size() - 1)
	return _apply_frame(current_frame_index)


func animation_duration() -> float:
	return float(_frames.size()) * _frame_time_seconds


func frame_count() -> int:
	return _frames.size()


func visual_fit_diagnostics() -> Dictionary:
	return {
		"anchor_policy": _anchor_policy,
		"sequence_index": direction_index,
		"sequence_bounds": _sequence_bounds,
		"sequence_anchor_rebase": _sequence_anchor_rebase,
		"source_axis_local": _source_axis_local,
		"source_cross_axis_local": _source_cross_axis_local,
		"longitudinal_scale": _longitudinal_scale,
		"fitted_forward_extent_px": fitted_visual_forward_extent(_source_axis_local),
		"fitted_cross_extent_px": fitted_visual_cross_extent(_source_axis_local),
	}


func visual_bounds_center() -> Vector2:
	return transform.basis_xform(
		_sequence_bounds.get_center() + _sequence_anchor_rebase
	)


func fitted_visual_bounds() -> Rect2:
	return _transformed_rect_bounds(_sequence_bounds, _sequence_anchor_rebase)


func fitted_visual_axis_extent(axis_world: Vector2) -> float:
	if axis_world.length_squared() <= 0.000001:
		return 0.0
	return _transformed_rect_projection_extent(
		_sequence_bounds, _sequence_anchor_rebase, axis_world.normalized()
	)


func fitted_visual_forward_extent(axis_world: Vector2) -> float:
	if axis_world.length_squared() <= 0.000001:
		return 0.0
	if _axis_cross_fit_active and current_frame_index >= 0:
		var visible_extent := _frame_visible_axis_extent(
			_frames[current_frame_index]
		)
		if visible_extent > 0.0:
			return visible_extent * absf(
				transform.basis_xform(_source_axis_local).dot(
					axis_world.normalized()
				)
			)
	return _transformed_rect_forward_projection_extent(
		_sequence_bounds,
		_sequence_anchor_rebase,
		axis_world.normalized()
	)


func fitted_visual_cross_extent(axis_world: Vector2) -> float:
	if axis_world.length_squared() <= 0.000001:
		return 0.0
	var normalized_axis := axis_world.normalized()
	return _transformed_rect_projection_extent(
		_sequence_bounds,
		_sequence_anchor_rebase,
		Vector2(-normalized_axis.y, normalized_axis.x)
	)


func current_frame_visual_forward_extent(axis_world: Vector2) -> float:
	if (
		axis_world.length_squared() <= 0.000001
		or current_frame_index < 0
		or current_frame_index >= _frames.size()
	):
		return 0.0
	if _axis_cross_fit_active:
		var visible_extent := _frame_visible_axis_extent(
			_frames[current_frame_index]
		)
		if visible_extent > 0.0:
			return visible_extent * absf(
				transform.basis_xform(_source_axis_local).dot(
					axis_world.normalized()
				)
			)
	var frame_rect := _visual_rect_for_frame(
		_frames[current_frame_index], _anchor_policy
	)
	return _transformed_rect_forward_projection_extent(
		frame_rect,
		_sequence_anchor_rebase,
		axis_world.normalized()
	)


func current_frame_visible_cross_extent(axis_world: Vector2) -> float:
	if (
		axis_world.length_squared() <= 0.000001
		or current_frame_index < 0
		or current_frame_index >= _frames.size()
	):
		return 0.0
	var native_extent := _frame_visible_cross_extent(_frames[current_frame_index])
	return native_extent * transform.basis_xform(_source_cross_axis_local).length()


func _apply_frame(frame_index: int) -> bool:
	if frame_index < 0 or frame_index >= _frames.size():
		return false
	var frame: Dictionary = _frames[frame_index]
	var path := "res://%s" % str(frame.get("path", ""))
	# perf-smoothness-r1 Phase C (audit): combat-time misses must never
	# synchronously load/decode on the main thread. Inside the loading window
	# this is the normal synchronous prewarm path; in combat a miss returns
	# null and the frame is skipped while the async warm-up channel fills it.
	var loaded := CasterSkillVisualRegistry.request_animation_frame_texture(path)
	if loaded == null:
		return false
	texture = loaded
	if is_instance_valid(_fire_wall_additive_sprite):
		_fire_wall_additive_sprite.texture = loaded
	_sync_trial_screen_copy_visibility()
	if _axis_cross_fit_active:
		_apply_axis_cross_transform(frame)
	var anchor_field := (
		"source_draw_offset"
		if _anchor_policy == "source_draw_offset_from_actor_foot"
		else "top_left_from_world_anchor"
	)
	var top_left: Array = frame.get(anchor_field, [0, 0])
	offset = Vector2(
		float(top_left[0]) + float(loaded.get_width()) * 0.5,
		float(top_left[1]) + float(loaded.get_height()) * 0.5
	) + _sequence_anchor_rebase
	if is_instance_valid(_fire_wall_additive_sprite):
		_fire_wall_additive_sprite.offset = offset
	skill_frame_changed.emit(frame_index)
	return true


func _apply_axis_cross_transform(frame: Dictionary) -> void:
	_apply_frame_source_axis(frame)
	if _anchor_policy == "align_sequence_visible_axis_start_to_geometry_origin":
		_sequence_anchor_rebase = _visible_axis_anchor_rebase(
			frame, _rebase_to_visible_axis_start(_sequence_bounds)
		)
	var visible_axis_extent := _frame_visible_axis_extent(frame)
	if visible_axis_extent > 0.0:
		_longitudinal_scale = (
			_desired_axis_extent / maxf(0.001, visible_axis_extent)
		)
	var native_cross_extent := _frame_visible_cross_extent(frame)
	var cross_scale := (
		_desired_cross_axis_extent / maxf(0.001, native_cross_extent)
	)
	var basis_x := (
		_fit_axis_world * (_source_axis_local.x * _longitudinal_scale)
		+ _target_cross_axis * (_source_cross_axis_local.x * cross_scale)
	)
	var basis_y := (
		_fit_axis_world * (_source_axis_local.y * _longitudinal_scale)
		+ _target_cross_axis * (_source_cross_axis_local.y * cross_scale)
	)
	transform = Transform2D(basis_x, basis_y, Vector2.ZERO)


func _apply_frame_source_axis(frame: Dictionary) -> void:
	var frame_axis := _vector2_pair(
		frame.get("visible_axis_local", []), _source_axis_local
	)
	if frame_axis.length_squared() <= 0.000001:
		return
	_source_axis_local = frame_axis.normalized()
	_source_cross_axis_local = Vector2(
		-_source_axis_local.y, _source_axis_local.x
	)


func _visible_axis_anchor_rebase(
	frame: Dictionary,
	fallback: Vector2
) -> Vector2:
	var axis_start := float(frame.get("visible_axis_start_pixels", INF))
	var cross_center := float(frame.get("visible_cross_center_pixels", INF))
	if not is_finite(axis_start) or not is_finite(cross_center):
		return fallback
	return (
		-axis_start * _source_axis_local
		- cross_center * _source_cross_axis_local
	)


func _frame_visible_axis_extent(frame: Dictionary) -> float:
	return maxf(0.0, float(frame.get("visible_axis_extent_pixels", 0.0)))


func _frame_visible_cross_extent(frame: Dictionary) -> float:
	var formal_alpha_extent := float(frame.get("visible_cross_extent_pixels", 0.0))
	if formal_alpha_extent > 0.0:
		return formal_alpha_extent
	return _rect_projection_extent(
		_visual_rect_for_frame(frame, _anchor_policy),
		_source_cross_axis_local
	)


func _vector2_pair(raw_value: Variant, fallback: Vector2) -> Vector2:
	if raw_value is Array and raw_value.size() >= 2:
		var candidate := Vector2(
			float(raw_value[0]),
			float(raw_value[1])
		)
		if candidate.length_squared() > 0.000001:
			return candidate
	return fallback


func _visual_rect_for_frame(frame: Dictionary, anchor_policy: String) -> Rect2:
	var anchor_field := (
		"source_draw_offset"
		if anchor_policy == "source_draw_offset_from_actor_foot"
		else "top_left_from_world_anchor"
	)
	var top_left: Array = frame.get(anchor_field, [0, 0])
	var pixel_size: Array = frame.get("pixel_size", [0, 0])
	return Rect2(
		Vector2(float(top_left[0]), float(top_left[1])),
		Vector2(float(pixel_size[0]), float(pixel_size[1]))
	)


func _visual_bounds_for_frames(frames: Array[Dictionary], anchor_policy: String) -> Rect2:
	var anchor_field := (
		"source_draw_offset"
		if anchor_policy == "source_draw_offset_from_actor_foot"
		else "top_left_from_world_anchor"
	)
	var minimum := Vector2(INF, INF)
	var maximum := Vector2(-INF, -INF)
	for frame: Dictionary in frames:
		var top_left: Array = frame.get(anchor_field, [0, 0])
		var pixel_size: Array = frame.get("pixel_size", [0, 0])
		var frame_minimum := Vector2(float(top_left[0]), float(top_left[1]))
		var frame_maximum := frame_minimum + Vector2(
			float(pixel_size[0]), float(pixel_size[1])
		)
		minimum.x = minf(minimum.x, frame_minimum.x)
		minimum.y = minf(minimum.y, frame_minimum.y)
		maximum.x = maxf(maximum.x, frame_maximum.x)
		maximum.y = maxf(maximum.y, frame_maximum.y)
	if frames.is_empty():
		return Rect2(Vector2.ZERO, Vector2.ONE)
	return Rect2(minimum, maximum - minimum)


func _rect_projection_extent(rect: Rect2, axis: Vector2) -> float:
	var normalized_axis := axis.normalized()
	return (
		absf(normalized_axis.x) * rect.size.x
		+ absf(normalized_axis.y) * rect.size.y
	)


func _rect_forward_projection_extent(
	rect: Rect2,
	anchor_rebase: Vector2,
	axis: Vector2
) -> float:
	var normalized_axis := axis.normalized()
	var minimum := rect.position + anchor_rebase
	var maximum := rect.end + anchor_rebase
	var forward_extent := -INF
	for corner: Vector2 in [
		minimum,
		Vector2(maximum.x, minimum.y),
		maximum,
		Vector2(minimum.x, maximum.y),
	]:
		forward_extent = maxf(forward_extent, corner.dot(normalized_axis))
	return maxf(0.001, forward_extent)


func _transformed_rect_bounds(rect: Rect2, anchor_rebase: Vector2) -> Rect2:
	var minimum := Vector2(INF, INF)
	var maximum := Vector2(-INF, -INF)
	for point: Vector2 in _rect_corners(rect, anchor_rebase):
		var transformed := transform.basis_xform(point)
		minimum.x = minf(minimum.x, transformed.x)
		minimum.y = minf(minimum.y, transformed.y)
		maximum.x = maxf(maximum.x, transformed.x)
		maximum.y = maxf(maximum.y, transformed.y)
	return Rect2(minimum, maximum - minimum)


func _transformed_rect_projection_extent(
	rect: Rect2,
	anchor_rebase: Vector2,
	axis: Vector2
) -> float:
	var minimum := INF
	var maximum := -INF
	var normalized_axis := axis.normalized()
	for point: Vector2 in _rect_corners(rect, anchor_rebase):
		var projection := transform.basis_xform(point).dot(normalized_axis)
		minimum = minf(minimum, projection)
		maximum = maxf(maximum, projection)
	return maxf(0.001, maximum - minimum)


func _transformed_rect_forward_projection_extent(
	rect: Rect2,
	anchor_rebase: Vector2,
	axis: Vector2
) -> float:
	var forward_extent := -INF
	var normalized_axis := axis.normalized()
	for point: Vector2 in _rect_corners(rect, anchor_rebase):
		forward_extent = maxf(
			forward_extent,
			transform.basis_xform(point).dot(normalized_axis)
		)
	return maxf(0.001, forward_extent)


func _rect_corners(rect: Rect2, anchor_rebase: Vector2) -> Array[Vector2]:
	var minimum := rect.position + anchor_rebase
	var maximum := rect.end + anchor_rebase
	return [
		minimum,
		Vector2(maximum.x, minimum.y),
		maximum,
		Vector2(minimum.x, maximum.y),
	]


func _rebase_to_visible_axis_start(bounds: Rect2) -> Vector2:
	# Shift the sequence bounds so the minimum projection onto the source
	# axis lands at the geometry origin. This prevents the animation from
	# extending backward (behind the caster) while keeping the forward
	# extent driven by the desired axis stretch.
	var source_axis_min: float = INF
	var cross_min: float = INF
	var cross_max: float = -INF
	var corners: PackedVector2Array = PackedVector2Array([
		bounds.position,
		bounds.position + Vector2(bounds.size.x, 0.0),
		bounds.position + bounds.size,
		bounds.position + Vector2(0.0, bounds.size.y),
	])
	for corner: Vector2 in corners:
		var axis_proj: float = corner.dot(_source_axis_local)
		source_axis_min = minf(source_axis_min, axis_proj)
		var cross_proj: float = corner.dot(_source_cross_axis_local)
		cross_min = minf(cross_min, cross_proj)
		cross_max = maxf(cross_max, cross_proj)
	var cross_center: float = (cross_min + cross_max) * 0.5
	return -source_axis_min * _source_axis_local - cross_center * _source_cross_axis_local
