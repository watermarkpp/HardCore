class_name SkillRuntimeRouter
extends RefCounted

const SkillDataLoaderScript := preload("res://scripts/skills/skill_data_loader.gd")
const ActionLease := preload("res://scripts/features/contracts/action_config_lease.gd")
const ChildLease := preload("res://scripts/features/contracts/child_action_lease.gd")
const SkillCastRequestScript := preload("res://scripts/skills/skill_cast_request.gd")
const SkillTargetServiceScript := preload("res://scripts/skills/skill_target_service.gd")
const SkillResourceServiceScript := preload("res://scripts/skills/skill_resource_service.gd")
const SkillGeometryServiceScript := preload("res://scripts/skills/skill_geometry_service.gd")
const SkillRngScript := preload("res://scripts/skills/skill_rng.gd")
const SkillRankResolverScript := preload(
	"res://scripts/skills/skill_rank_resolver.gd"
)
const WarriorRuntimeScript := preload("res://scripts/skills/runtimes/warrior_skill_runtime.gd")
const WizardRuntimeScript := preload("res://scripts/skills/runtimes/wizard_skill_runtime.gd")
const TaoistRuntimeScript := preload("res://scripts/skills/runtimes/taoist_skill_runtime.gd")
const SkillExecutionPlanContractScript := preload(
	"res://scripts/skills/skill_execution_plan_contract.gd"
)

const RUNTIME_CONTRACT_ID := "skills.runtime_router.cn_mir2_176.v1"
const CANONICAL_PRODUCTION_DEFAULT := true
const WARRIOR_MELEE_MODIFIER_CONTRACT_ID := "gameplay.warrior.melee_modifiers.v2"


static func _plan(request: Variant, definition: Dictionary = {}) -> Dictionary:
	## Q3-C: the SINGLE planner baseline used by the canonical formal entry
	## build_canonical_plan(). Pure: no resource commits, no cooldown commits,
	## no node creation, no release snapshot building.
	var request_validation := SkillCastRequestScript.validate(request)
	if not bool(request_validation.get("valid", false)):
		return {
			"accepted": false,
			"effect_success": false,
			"resource_commit": false,
			"reason": str(
				request_validation.get("reason", "invalid_request")
			),
		}
	var child: RefCounted = ChildLease.from_request(request)
	if request.has("child_action_lease") and child==null:
		return {"accepted":false,"effect_success":false,"resource_commit":false,"reason":"invalid_request"}
	var skill_id := str(request.skill_id) if child!=null else SkillDataLoaderScript.stable_skill_id(str(request.get("skill_id", "")))
	var resolved_request: Dictionary = request
	if SkillRankResolverScript.mode_for(skill_id) == "EXCLUDED" and int(request.get("rank", 0)) > 3:
		resolved_request = request.duplicate(false)
		resolved_request["rank"] = SkillRankResolverScript.formula_rank(request.get("rank", 0))
	if definition.is_empty():
		definition = child.definition() if child!=null else ActionLease.resolve_definition(skill_id, request.get("action_config_lease"))
	if definition.is_empty():
		return {
			"accepted": false,
			"effect_success": false,
			"resource_commit": false,
			"skill_id": skill_id,
			"reason": "unknown_skill",
		}
	var target_validation := SkillTargetServiceScript.validate(
		definition,
		request.get("target_context", {})
	)
	if not bool(target_validation.get("valid", false)):
		return {
			"accepted": false,
			"effect_success": false,
			"resource_commit": false,
			"skill_id": skill_id,
			"reason": str(
				target_validation.get("reason", "invalid_target")
			),
		}
	var resource_quote := SkillResourceServiceScript.quote(
		definition,
		int(resolved_request.get("rank", 0)),
		resolved_request.get("resource_context", {}),
		resolved_request.get("target_context", {})
	)
	if not bool(resource_quote.get("valid", false)):
		return {
			"accepted": false,
			"effect_success": false,
			"resource_commit": false,
			"skill_id": skill_id,
			"reason": str(
				resource_quote.get("reason", "insufficient_resource")
			),
		}
	var rng := SkillRngScript.new(int(resolved_request.get("seed", 0)))
	var plan: Dictionary
	match str(definition.get("class", "")):
		"child_action":
			if child==null: return {"accepted":false,"reason":"invalid_request"}
			var command: Dictionary=child.command()
			plan={"accepted":true,"effect_success":true,"resource_commit_required":false,
				"effects":[{"type":"area_damage","raw_power":int(command.raw_damage),
					"radius_gu":float(command.radius_gu),"source_class":"child","damage_channel":"magic_defense",
					"causes_struck":false,"direct_magic_walk_delay":false}]}
		"warrior":
			plan = WarriorRuntimeScript.execute(definition, resolved_request, rng)
		"wizard":
			plan = WizardRuntimeScript.execute(definition, resolved_request, rng)
		"taoist":
			plan = TaoistRuntimeScript.execute(definition, resolved_request, rng)
		_:
			return {
				"accepted": false,
				"effect_success": false,
				"resource_commit": false,
				"skill_id": skill_id,
				"reason": "unknown_profession",
			}
	plan["skill_id"] = skill_id
	if not bool(plan.get("accepted", true)):
		plan["effect_success"] = false
		plan["resource_commit"] = false
		plan["reason"] = str(plan.get("reason", "runtime_rejected"))
		return plan
	plan["timing"] = definition.get("timing", {}).duplicate(true)
	plan["geometry"] = definition.get("geometry", {}).duplicate(true)
	plan["target"] = definition.get("target", {}).duplicate(true)
	plan["resource"] = resource_quote.duplicate(true)
	plan["mechanics"] = definition.get("mechanics", {}).duplicate(true)
	plan["geometry_cells"] = [] if child!=null else SkillGeometryServiceScript.cells(
		definition,
		request.get("origin_tile", Vector2i.ZERO),
		request.get("facing", Vector2i.DOWN),
		request.get("target_context", {}).get("target_tile", Vector2i.ZERO)
	)
	plan["resource_quote"] = resource_quote
	## The release freezes the effective rank used to build every effect.
	plan["effective_rank"] = SkillRankResolverScript.safe_effective_rank(
		int(resolved_request.get("rank", 0))
	)
	return plan


## Q3-B: the SINGLE formal planner entry. GameRoot calls ONLY this function to
## obtain the canonical plan; the legacy execute() above is no longer called by
## the formal production chain (kept for compatibility/shadow).
static func build_canonical_plan(
	request: Variant,
	context: Dictionary = {}
) -> Dictionary:
	var request_validation := SkillCastRequestScript.validate(request)
	if not bool(request_validation.get("valid", false)):
		return _canonical_rejection_plan(
			"",
			str(request_validation.get("reason", "invalid_request")),
			request,
			context
		)
	var child: RefCounted = ChildLease.from_request(request)
	if request.has("child_action_lease"):
		if child==null: return _canonical_rejection_plan("","invalid_request",request,context)
		context=child.planning_context(context)
		if context.is_empty(): return _canonical_rejection_plan(str(request.skill_id),"invalid_request",request,{})
	var skill_id := str(request.skill_id) if child!=null else SkillDataLoaderScript.stable_skill_id(
		str(request.get("skill_id", ""))
	)
	var definition: Dictionary = child.definition() if child!=null else ActionLease.resolve_definition(skill_id, request.get("action_config_lease"))
	if definition.is_empty():
		return _canonical_rejection_plan(
			skill_id,
			"unknown_skill",
			request,
			context
		)
	var resolved_request: Dictionary = request
	if SkillRankResolverScript.mode_for(skill_id) == "EXCLUDED" and int(request.get("rank", 0)) > 3:
		resolved_request = request.duplicate(false)
		resolved_request["rank"] = SkillRankResolverScript.formula_rank(request.get("rank", 0))
	var legacy_result := _plan(resolved_request, definition)
	return SkillExecutionPlanContractScript.build_canonical_plan(
		legacy_result,
		resolved_request,
		context
	)


# Only constructs immutable input. All planning still goes through the one
# build_canonical_plan entry and its existing domain/snapshot envelope.
static func create_child_request(command: Dictionary, world: RefCounted, release_id: String) -> Dictionary:
	return ChildLease.create(command,world,release_id)


static func _canonical_rejection_plan(
	skill_id: String,
	reason: String,
	request: Variant,
	context: Dictionary
) -> Dictionary:
	var normalized := SkillExecutionPlanContractScript.normalize_reason(reason)
	var release_id := str(
		context.get(
			"release_id",
			request.get("target_context", {}).get("release_id", "")
		)
	)
	if release_id.is_empty():
		release_id = "canonical:%s:%d" % [
			skill_id,
			int(request.get("seed", 0)),
		]
	return {
		"contract": SkillExecutionPlanContractScript.CONTRACT_ID,
		"plan_version": 1,
		"plan_id": "",
		"release_id": release_id,
		"skill_id": skill_id,
		"skill_definition_revision": "",
		"caster_runtime_id": int(context.get("caster_runtime_id", 0)),
		"target_runtime_id": int(context.get("target_runtime_id", 0)),
		"runtime_map_id": int(context.get("runtime_map_id", -1)),
		"input_mode": str(context.get("input_mode", "canonical")),
		"effective_rank": SkillRankResolverScript.safe_effective_rank(
			int(request.get("rank", 0))
		),
		"requested_direction": request.get("facing", Vector2i.DOWN),
		"resolved_direction": request.get("facing", Vector2i.DOWN),
		"lock_on_context": {},
		"resource_cost": {},
		"cooldown_contract": {},
		"canonical_snapshot": {},
		"snapshot_id": "",
		"snapshot_required": not SkillExecutionPlanContractScript.NON_SPATIAL_SKILLS.has(
			skill_id
		),
		"non_spatial_reason": str(
			SkillExecutionPlanContractScript.NON_SPATIAL_SKILLS.get(
				skill_id,
				""
			)
		),
		"geometry_cells": [],
		"gameplay_actions": [],
		"presentation_actions": [],
		"projectile_descriptors": [],
		"ground_effect_descriptors": [],
		"summon_descriptors": [],
		"rejection": {"accepted": false, "reason": normalized},
		"created_by": SkillExecutionPlanContractScript.CANONICAL_PLANNER_ID,
		"legacy_planner": SkillExecutionPlanContractScript.LEGACY_PLANNER_ID,
	}


static func taoist_melee_accuracy_bonus(rank: int, configuration: RefCounted = null) -> int:
	var definition := ActionLease.resolve_definition("taoist.spiritual_warfare", configuration)
	var plan := TaoistRuntimeScript.execute(
		definition, {"rank": rank}, SkillRngScript.new(0)
	)
	var bonus := 0
	for effect: Dictionary in plan.get("effects", []):
		if (
			str(effect.get("type", "")) == "passive_stat_modifier"
			and str(effect.get("stat", "")) == "accuracy"
			and "physical_melee_hit_checks" in effect.get("affects", [])
		):
			bonus += int(effect.get("value", 0))
	return bonus


static func resolve_warrior_melee_modifiers(request: Dictionary) -> Dictionary:
	var valid_melee_swing := bool(request.get("valid_melee_swing", false))
	var body_mode := str(request.get("body_mode", "normal"))
	if body_mode not in ["normal", "thrust", "half_moon", "fire"]:
		body_mode = "normal"
	var basic_learned := bool(request.get("basic_sword_learned", false))
	var slaying_learned := bool(request.get("slaying_learned", false))
	var basic_rank := SkillRankResolverScript.safe_effective_rank(
		int(request.get("basic_sword_rank", 0))
	)
	var slaying_rank := SkillRankResolverScript.safe_effective_rank(
		int(request.get("slaying_rank", 0))
	)
	var rng := SkillRngScript.new(int(request.get("seed", 0)))
	var flat_dc_bonus := 0
	var flat_damage_bonus_after_body_formula := 0
	var flat_accuracy_bonus := 0
	## Proficiency is disabled in HardCore v2: the compatibility array always
	## stays empty and never grows/upgrades/persists anything.
	var proficiency_events: Array[Dictionary] = []
	var effects: Array[Dictionary] = []
	var slaying_proc := false
	var slaying_proc_roll_count := 0
	var slaying_proc_denominator := 0
	var slaying_proc_roll := -1

	if basic_learned:
		var basic_definition := ActionLease.resolve_definition("warrior.basic_swordsmanship", request.get("action_config_lease"))
		var basic_plan := WarriorRuntimeScript.execute(
			basic_definition,
			{
				"rank": basic_rank,
				"target_context": {"valid_melee_swing": valid_melee_swing},
			},
			rng
		)
		for raw_effect: Variant in basic_plan.get("effects", []):
			if raw_effect is Dictionary:
				var effect: Dictionary = raw_effect
				effects.append(effect.duplicate(true))
				if str(effect.get("type", "")) == "passive_stat_modifier":
					flat_accuracy_bonus += int(effect.get("value", 0))
	if slaying_learned:
		var slaying_definition := ActionLease.resolve_definition("warrior.slaying_swordsmanship", request.get("action_config_lease"))
		var mechanics: Dictionary = slaying_definition.get("mechanics", {})
		var accuracy_values: Array = mechanics.get("flat_accuracy_bonus_by_rank", [0, 1, 2, 3])
		var denominator_values: Array = mechanics.get("proc_denominator_by_rank", [7, 6, 5, 4])
		flat_accuracy_bonus += SkillRankResolverScript.linear_int(
			accuracy_values,
			SkillRankResolverScript.formula_rank(slaying_rank)
		) + maxi(0, slaying_rank - 3)
		slaying_proc_denominator = SkillRankResolverScript.denominator(
			denominator_values,
			slaying_rank
		)
		if valid_melee_swing:
			slaying_proc_roll_count = 1
			var slaying_context := {
				"valid_melee_swing": true,
				"has_target": true,
				"force_proc": bool(request.get("force_slaying_proc", false)),
				"force_no_proc": bool(request.get("force_no_slaying_proc", false)),
			}
			if request.has("slaying_proc_roll"):
				slaying_context["proc_roll"] = int(request.get("slaying_proc_roll", 0))
			var slaying_plan := WarriorRuntimeScript.execute(
				slaying_definition,
				{"rank": slaying_rank, "target_context": slaying_context},
				rng
			)
			for raw_effect: Variant in slaying_plan.get("effects", []):
				if not raw_effect is Dictionary:
					continue
				var effect: Dictionary = raw_effect
				effects.append(effect.duplicate(true))
				if str(effect.get("type", "")) != "melee_proc_modifier":
					continue
				slaying_proc = bool(effect.get("proc", false))
				slaying_proc_denominator = int(effect.get("proc_denominator", slaying_proc_denominator))
				slaying_proc_roll = int(effect.get("proc_roll", -1))
				if slaying_proc:
					flat_damage_bonus_after_body_formula = int(
						effect.get("flat_damage_bonus", 0)
					)
	return {
		"contract_id": WARRIOR_MELEE_MODIFIER_CONTRACT_ID,
		"source_ruleset_id": SkillDataLoaderScript.RULESET_ID,
		"valid_melee_swing": valid_melee_swing,
		"body_mode": body_mode,
		"flat_dc_bonus_before_body_formula": flat_dc_bonus,
		"flat_damage_bonus_after_body_formula": flat_damage_bonus_after_body_formula,
		"flat_accuracy_bonus": flat_accuracy_bonus,
		"slaying_proc": slaying_proc,
		"slaying_proc_roll_count": slaying_proc_roll_count,
		"slaying_proc_denominator": slaying_proc_denominator,
		"slaying_proc_roll": slaying_proc_roll,
		"slaying_effect_skill_id": (
			"warrior.slaying_swordsmanship" if slaying_proc else ""
		),
		"modifier_order": [
			"base_damage",
			"selected_body_skill_formula",
			"flat_damage_bonus_after_body_formula",
		],
		"scope": "all_hits_of_selected_melee_action",
		"requires_one_call_per_action": true,
		"body_mode_agnostic": true,
		"effects": effects,
		"proficiency_events": proficiency_events,
	}


static func integration_descriptor() -> Dictionary:
	return {
		"runtime_contract": RUNTIME_CONTRACT_ID,
		"warrior_melee_modifier_contract": WARRIOR_MELEE_MODIFIER_CONTRACT_ID,
		"warrior_melee_modifier_entrypoint": "SkillRuntimeRouter.resolve_warrior_melee_modifiers",
		"production_default": CANONICAL_PRODUCTION_DEFAULT,
		"entrypoint": "SkillRuntimeRouter.build_canonical_plan",
		"request_contract": SkillCastRequestScript.CONTRACT_ID,
		"result_contract": "skill_execution_result.v1",
		"requires_integration_adapters": [
			"combat_resolution",
			"inventory_resources",
			"map_tile_geometry",
			"target_relations",
			"buff_runtime",
			"taoist_main_pet",
		],
	}
