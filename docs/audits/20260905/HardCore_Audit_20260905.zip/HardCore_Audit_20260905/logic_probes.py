#!/usr/bin/env python3
"""Small Python logic models of inspected fragments, NOT execution of HardCore/Godot."""
from __future__ import annotations
import json
from pathlib import Path


def model(seconds: float, fps: int, continuous_movement: bool) -> dict:
    dt = 1.0 / fps
    fail_safe = visual_remaining = elapsed = bob = 0.0
    retry = 5.0
    visual_ticks = collection_passes = 0
    for _ in range(round(seconds * fps)):
        # Model a movement notification before every manager process frame.
        # Player stays inside one pickup's radius; no leave-range reset applies.
        if continuous_movement:
            elapsed = 0.0
            fail_safe = 0.1
            # Movement-triggered collection receives delta=0, so retry is unchanged.
        elapsed += dt
        fail_safe -= dt
        visual_remaining -= dt
        if fail_safe <= 0:
            fail_safe = 0.1
            retry = max(0.0, retry - elapsed)
            elapsed = 0.0
            collection_passes += 1
        if visual_remaining <= 0:
            visual_remaining = 1.0 / 30.0
            bob += dt  # inspected code passes only the current render delta
            visual_ticks += 1
    return {'seconds': seconds, 'fps': fps, 'continuous_movement': continuous_movement,
            'retry_remaining': round(retry, 6), 'visual_time': round(bob, 6),
            'visual_ticks': visual_ticks, 'fail_safe_collection_passes': collection_passes}


def run() -> dict:
    idle = model(6, 60, False)
    moving = model(6, 60, True)
    visuals = [model(1, fps, False) for fps in (30, 60, 120)]
    assert idle['retry_remaining'] == 0
    assert moving['retry_remaining'] == 5
    assert visuals[0]['visual_time'] > visuals[1]['visual_time'] > visuals[2]['visual_time']
    template = {'name': 'SYNTHETIC_STACKABLE_FIXTURE', 'count': 4, 'fixture_extra_field': 'preserve-me'}
    rebuilt = {'name': template['name'], 'count': template['count']}
    assert 'fixture_extra_field' not in rebuilt
    return {'scope': 'Python models only. No Godot/HardCore executable or real item configuration used.',
            'actual_engine_tests': 'NOT_RUN', 'assertions': 'PASS',
            'idle_cooldown_model': idle, 'continuous_movement_model': moving,
            'visual_time_models': visuals,
            'stack_rebuild_model': {'input': template, 'output': rebuilt,
                                    'lost_fields': sorted(set(template) - set(rebuilt))},
            'insertion_sort_worst_case_comparisons': {str(k): k * (k - 1) // 2 for k in (100, 500, 1000)}}


if __name__ == '__main__':
    result = run()
    path = Path(__file__).with_name('logic_probe_results.json')
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
