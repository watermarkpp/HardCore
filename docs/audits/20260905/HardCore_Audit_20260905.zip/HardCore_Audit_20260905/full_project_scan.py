#!/usr/bin/env python3
"""Read-only tracked-file inventory and lexical audit. No Godot code is executed.

Output is a review queue, not proof of bugs/dead code. Text paths may be comments,
fixtures or dynamic prefixes. Run on the intended checkout; dirty files are recorded.
Python 3.10+. Standard library only. Writes only the requested new report directory.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

TEXT_EXTS = {'.gd', '.tscn', '.tres', '.godot', '.cfg', '.json', '.md', '.txt',
             '.py', '.ps1', '.psm1', '.sh', '.yml', '.yaml', '.toml', '.ini', '.uid', '.csv'}
RESOURCE = re.compile(r'''["'](res://[^"'\r\n]+)["']''')
FUNC = re.compile(r'^\s*(?:static\s+)?func\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(', re.M)
CLASS = re.compile(r'^\s*class_name\s+([A-Za-z_][A-Za-z_0-9]*)', re.M)


def git(root: Path, *args: str) -> bytes:
    p = subprocess.run(['git', '-C', str(root), *args], capture_output=True, check=False)
    if p.returncode:
        raise RuntimeError(p.stderr.decode('utf-8', 'replace').strip() or 'git failed')
    return p.stdout


def under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def scan(root: Path, out: Path, expected: str | None, hash_all: bool,
         max_text_mib: int) -> dict[str, Any]:
    root = root.resolve(strict=True)
    repo_root = Path(git(root, 'rev-parse', '--show-toplevel').decode().strip()).resolve()
    if root != repo_root:
        raise ValueError('--root must be the repository top level')
    head = git(root, 'rev-parse', 'HEAD').decode().strip()
    if expected and head != expected:
        raise ValueError(f'HEAD mismatch: expected {expected}, actual {head}; no scan was performed')
    out = out.resolve()
    if out.exists():
        raise ValueError('Output directory already exists; use a NEW directory to preserve evidence')
    names = sorted(set(p.decode('utf-8', 'surrogateescape')
                       for p in git(root, 'ls-files', '-z').split(b'\0') if p))
    lower: dict[str, list[str]] = collections.defaultdict(list)
    for name in names:
        lower[name.casefold()].append(name)
    dirty = git(root, 'status', '--porcelain=v1', '-z', '--untracked-files=normal')
    manifest: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    hashes: dict[str, list[str]] = collections.defaultdict(list)
    classes: dict[str, list[str]] = collections.defaultdict(list)
    uids: dict[str, list[str]] = collections.defaultdict(list)
    cap = max_text_mib * 1024 * 1024
    text_count = json_count = reference_count = 0
    for name in names:
        path = root / name
        entry: dict[str, Any] = {'path': name, 'status': 'not_read', 'sha256': None}
        manifest.append(entry)
        if path.is_symlink() or not under(path.resolve(), root):
            entry['status'] = 'skipped_link_or_outside_root'
            skipped.append({'path': name, 'reason': entry['status']})
            continue
        if not path.is_file():
            entry['status'] = 'missing_or_non_file'
            candidates.append({'kind': entry['status'], 'path': name})
            continue
        try:
            entry['bytes'] = path.stat().st_size
            with path.open('rb') as f:
                header = f.read(160)
            if header.startswith(b'version https://git-lfs.github.com/spec/v1'):
                entry['status'] = 'lfs_pointer_not_asset_bytes'
                skipped.append({'path': name, 'reason': entry['status']})
                continue
            is_text = path.suffix.lower() in TEXT_EXTS
            if hash_all or is_text:
                entry['sha256'] = digest_file(path)
                hashes[entry['sha256']].append(name)
            if not is_text:
                entry['status'] = 'binary_hashed' if hash_all else 'binary_inventory_only'
                continue
            if entry['bytes'] > cap:
                entry['status'] = 'text_over_size_limit'
                skipped.append({'path': name, 'reason': entry['status'], 'bytes': entry['bytes']})
                continue
            text = path.read_text(encoding='utf-8-sig', errors='strict')
            entry['status'] = 'text_lexically_scanned'
            entry['lines'] = len(text.splitlines())
            text_count += 1
            if path.suffix.lower() == '.json':
                duplicates: list[str] = []
                def pairs_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
                    obj: dict[str, Any] = {}
                    for k, v in pairs:
                        if k in obj:
                            duplicates.append(k)
                        obj[k] = v
                    return obj
                def bad_constant(value: str) -> Any:
                    raise ValueError(f'nonstandard JSON constant {value}')
                try:
                    json.loads(text, object_pairs_hook=pairs_hook, parse_constant=bad_constant)
                    json_count += 1
                    if duplicates:
                        candidates.append({'kind': 'duplicate_json_keys', 'path': name,
                                           'keys': sorted(set(duplicates))[:50]})
                except (ValueError, RecursionError) as exc:
                    candidates.append({'kind': 'json_parse_failure', 'path': name,
                                       'detail': str(exc)[:400]})
            if path.suffix.lower() == '.gd':
                entry['lexical_function_count'] = len(FUNC.findall(text))
                for classname in CLASS.findall(text):
                    classes[classname].append(name)
            if name.endswith('.uid'):
                uid = text.strip()
                if uid.startswith('uid://'):
                    uids[uid].append(name)
                if name[:-4] not in names:
                    candidates.append({'kind': 'orphan_uid_candidate', 'path': name,
                                       'expected_owner': name[:-4]})
            if path.suffix.lower() in {'.gd', '.tscn', '.tres', '.godot', '.cfg', '.json'}:
                for match in RESOURCE.finditer(text):
                    reference_count += 1
                    raw = match.group(1)
                    rel = raw[6:]
                    if any(c in rel for c in '*%{}'):
                        continue  # dynamic patterns are explicitly outside literal resolution
                    candidate = root / rel
                    if candidate.exists() and under(candidate.resolve(), root):
                        continue
                    candidates.append({'kind': 'literal_resource_reference_candidate', 'path': name,
                                       'line': text.count('\n', 0, match.start()) + 1,
                                       'reference': raw, 'case_candidates': lower.get(rel.casefold(), []),
                                       'note': 'Lexical only; may be comment, fixture or generated resource'})
        except (OSError, UnicodeError, ValueError) as exc:
            entry['status'] = 'read_error'
            skipped.append({'path': name, 'reason': 'read_error', 'detail': str(exc)[:300]})
    for classname, paths in classes.items():
        if len(paths) > 1:
            candidates.append({'kind': 'duplicate_class_name_candidate', 'name': classname, 'paths': paths})
    for uid, paths in uids.items():
        if len(paths) > 1:
            candidates.append({'kind': 'duplicate_uid_candidate', 'uid': uid, 'paths': paths})
    result: dict[str, Any] = {
        'tool': 'hardcore_read_only_inventory_v1', 'head': head, 'root': str(root),
        'scope': 'git tracked working-tree files; untracked sources and external assets are NOT scanned',
        'dirty_status_raw': dirty.decode('utf-8', 'replace').replace('\0', '\n'),
        'tracked_paths': len(names), 'text_files_scanned': text_count,
        'json_files_parsed': json_count, 'resource_literals_seen': reference_count,
        'hash_all': hash_all, 'max_text_mib': max_text_mib,
        'status_counts': dict(collections.Counter(e['status'] for e in manifest)),
        'candidate_count': len(candidates), 'skipped_count': len(skipped),
        'exact_content_duplicate_groups': [paths for paths in hashes.values() if len(paths) > 1],
        'case_collision_groups': [paths for paths in lower.values() if len(paths) > 1],
        'limitations': ['Not a GDScript parser or call graph', 'No Godot or device tests executed',
                       'No automatic dead-code proof', 'No asset semantic/visual validation',
                       'Dynamic references, UID imports, submodules and external sources need separate review',
                       'Dirty working tree is recorded, not silently reset'],
    }
    out.mkdir(parents=True, exist_ok=False)
    for filename, data in [('summary.json', result), ('manifest.json', manifest),
                           ('review_candidates.json', candidates), ('skipped.json', skipped)]:
        (out / filename).write_text(json.dumps(data, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
    return result


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True, help='Must be a NEW output directory')
    p.add_argument('--expected-sha', default=None)
    p.add_argument('--hash-all', action='store_true', help='Read binary bytes too; not a visual/format audit')
    p.add_argument('--max-text-mib', type=int, default=32)
    args = p.parse_args()
    if not 1 <= args.max_text_mib <= 1024:
        p.error('--max-text-mib must be between 1 and 1024')
    try:
        result = scan(args.root, args.out, args.expected_sha, args.hash_all, args.max_text_mib)
        print(json.dumps({k: result[k] for k in ('head', 'tracked_paths', 'text_files_scanned',
                                               'candidate_count', 'skipped_count')}, indent=2))
        print('Inventory complete. Candidates are NOT confirmed bugs. Godot tests: NOT_RUN.')
        return 0
    except (OSError, RuntimeError, ValueError) as exc:
        print(f'Audit failed: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
