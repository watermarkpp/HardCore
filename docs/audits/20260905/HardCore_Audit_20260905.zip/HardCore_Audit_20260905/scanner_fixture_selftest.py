#!/usr/bin/env python3
"""Synthetic scanner self-test only. Never reads or modifies the HardCore repository."""
from __future__ import annotations
import importlib.util
import json
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

def main() -> None:
    spec = importlib.util.spec_from_file_location('full_project_scan', HERE / 'full_project_scan.py')
    assert spec and spec.loader
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    with tempfile.TemporaryDirectory(prefix='hardcore_scanner_fixture_') as tmp:
        base = Path(tmp)
        root = base / 'fixture_repo'
        root.mkdir()
        def git(*args: str) -> str:
            proc = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, check=True)
            return proc.stdout.strip()
        git('init', '-q')
        files = {
            'project.godot': 'config_version=5\n[application]\nrun/main_scene="res://scenes/Missing.tscn"\n',
            'scripts/a.gd': 'class_name FixtureDuplicate\nextends Node\nconst TEX="res://assets/icon.png"\n',
            'scripts/b.gd': 'class_name FixtureDuplicate\nextends Node\n',
            'scripts/orphan.gd.uid': 'uid://fixtureduplicate\n',
            'scripts/a.gd.uid': 'uid://fixtureduplicate\n',
            'data/invalid.json': '{"a":}',
            'data/duplicate.json': '{"a": 1, "a": 2}',
            'data/good.json': '{"ok":true}',
            'docs/a.txt': 'exact duplicate fixture\n',
            'docs/b.txt': 'exact duplicate fixture\n',
            'assets/remote.png': 'version https://git-lfs.github.com/spec/v1\noid sha256:' + 'a'*64 + '\nsize 9\n',
        }
        for name, content in files.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding='utf-8')
        (root / 'assets/Icon.png').write_bytes(b'not-a-real-image-fixture')
        git('add', '--all')
        git('-c', 'user.name=Fixture Test', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'synthetic fixture')
        sha = git('rev-parse', 'HEAD')
        summary = scanner.scan(root, base / 'scan_out', sha, True, 32)
        candidates = json.loads((base / 'scan_out/review_candidates.json').read_text())
        kinds = {item['kind'] for item in candidates}
        required = {'json_parse_failure', 'duplicate_json_keys', 'orphan_uid_candidate',
                    'duplicate_uid_candidate', 'duplicate_class_name_candidate',
                    'literal_resource_reference_candidate'}
        assert required <= kinds, (required, kinds)
        assert summary['tracked_paths'] == 12, summary
        assert summary['status_counts']['lfs_pointer_not_asset_bytes'] == 1
        assert any(set(paths) == {'docs/a.txt', 'docs/b.txt'} for paths in summary['exact_content_duplicate_groups'])
        assert any(item.get('case_candidates') == ['assets/Icon.png'] for item in candidates)
        try:
            scanner.scan(root, base / 'wrong_sha_out', '0'*40, False, 32)
        except ValueError as exc:
            assert 'HEAD mismatch' in str(exc)
        else:
            raise AssertionError('Expected SHA mismatch rejection')
        assert not (base / 'wrong_sha_out').exists()
        try:
            scanner.scan(root, base / 'scan_out', sha, False, 32)
        except ValueError as exc:
            assert 'already exists' in str(exc)
        else:
            raise AssertionError('Expected output overwrite rejection')
        assert git('status', '--porcelain') == '', 'Scanner changed synthetic repository'
        result = {
            'scope': 'Synthetic temporary Git repository only; not HardCore',
            'status': 'PASS', 'hardcore_real_repository_scan': 'NOT_RUN',
            'godot_tests': 'NOT_RUN', 'fixture_tracked_paths': summary['tracked_paths'],
            'verified': ['invalid JSON detection', 'duplicate JSON key detection',
                         'orphan UID candidate', 'duplicate UID candidate',
                         'duplicate class name candidate', 'missing literal resource candidate',
                         'case-mismatch candidate on this Linux fixture',
                         'exact-content duplicate groups', 'LFS pointer skip accounting',
                         'expected SHA rejection without output', 'output overwrite rejection',
                         'synthetic repository remains clean'],
            'limitations': ['Does not validate GDScript semantics', 'Does not validate real resources',
                            'Does not establish Windows behavior or HardCore findings']
        }
        (HERE / 'scanner_fixture_selftest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
